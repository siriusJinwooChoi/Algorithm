import java.util.Scanner;
import java.util.Stack;

public class Main {

	public static void main(String arg[]){
		Scanner sc = new Scanner(System.in);
		int n = sc.nextInt();
		int arr[] = new int[n+1];
		for(int i=1 ; i<=n ; i++) {
			arr[i] = sc.nextInt();
		}
		
		int dp[] = new int[n+1];
		dp[1] = 1;
		int path[] = new int[n+1];
 		int resultMax = 0, resultMaxId = 0;
		for(int i=1 ; i<=n ; i++) {
			int max = 0;
			for(int j=i ; j>=1 ; j--) {
				if(arr[j] < arr[i]) {
					if(max < dp[j]) {
						max = dp[j];
						path[i] = j;
					}
				}
			}
			dp[i] = max+1;
			if(resultMax < dp[i]) {
				resultMax = dp[i];
				resultMaxId = i;
			}
		}
		
		System.out.println(resultMax);
		Stack<Integer> result = new Stack<Integer>();
		while(resultMaxId != 0) {
			result.push(arr[resultMaxId]);
			resultMaxId = path[resultMaxId];
		}
		
		while(!result.isEmpty()) {
			System.out.printf("%d ", result.pop());
		}
	}
}