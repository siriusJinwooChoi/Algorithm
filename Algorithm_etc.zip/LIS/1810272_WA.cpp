
#include<iostream>
#include<stdio.h>
using namespace std;

int data[500000];
int up[500000];
int front[500000];

int main() {
	//freopen("Text.txt", "r", stdin);
	int n, max, result=0, longIndex;
	cin >> n;
	for (int i = 0; i < n; i++) {
		cin >> data[i];
	}
	for (int i = 0; i < n; i++) {
		max = 0;
		for (int j = i - 1; j >= 0; j--) {
			if (data[i] > data[j]) {
				if (up[j] > max) {
					max = up[j];
					front[i] = j;
				}
			}
		}
		up[i] = max + 1;
		if (max == 0)
			front[i] = -1;
		if (result < up[i]) {
			result = up[i];
			longIndex = i;
		}
	}
	cout << result<<endl;
	while (1) {
		cout << data[longIndex] << " ";
		longIndex = front[longIndex];
		if (front[longIndex] == -1){
			cout << data[longIndex] << " ";
			break;
		}
	}

	return 0;
}