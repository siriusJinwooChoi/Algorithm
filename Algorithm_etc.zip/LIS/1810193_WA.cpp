#include<stdio.h>
#include<algorithm>
#define MaxN 500010
using namespace std;
int n,data[MaxN],lis[MaxN],lower,size;
int pos[MaxN],from[MaxN];
void f(int x)
{
    if(x==-1) return;
    f(from[x]);
    printf("%d ",data[x]);
}
int main()
{
    freopen("input.txt","r",stdin);
    freopen("output.txt","w",stdout);
    int i;
    scanf("%d",&n);
    for(i=1; i<=n; i++) scanf("%d",&data[i]);
    pos[0]=-1;
    for(i=1; i<=n; i++)
    {
        lower=lower_bound(lis+1,lis+1+size,data[i])-lis;
        if(lower>size) size=lower;
        lis[lower]=data[i];
        pos[lower]=i;
        from[i]=pos[lower-1];
    }
    printf("%d\n",size);
    f(pos[size]);
    return 0;
}