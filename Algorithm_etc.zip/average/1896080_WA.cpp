#include <iostream>
int main(){
int a,b,c,d;float av;
std::cin>>a>>b>>c>>d;
av=(a+b+c+d)/4;
printf("%.2f",av);
}