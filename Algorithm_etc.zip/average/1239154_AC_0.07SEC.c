#include <stdio.h>
int A,B,C,D;
double Avg;
int main(){

	scanf("%d %d %d %d", &A,&B,&C,&D);

	Avg = (double)(A+B+C+D)/4;

	printf("%.2f", Avg);

	return 0;
}