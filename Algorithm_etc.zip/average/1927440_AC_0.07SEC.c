
#include <stdio.h>

void main() {
	int a, b, c, d;
	double ave = 0;

	scanf("%d %d %d %d", &a, &b, &c, &d);
	ave = (a+b+c+d) / 4.0;
	printf("%.2f\n", ave);
}