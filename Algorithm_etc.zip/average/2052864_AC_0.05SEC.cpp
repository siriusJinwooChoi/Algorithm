#include <stdio.h>

int main(void) {
	int a, b, c, d;

	scanf("%d %d %d %d", &a, &b, &c, &d);

	printf("%.2lf\n", (double)(a + b + c + d) / 4);
}