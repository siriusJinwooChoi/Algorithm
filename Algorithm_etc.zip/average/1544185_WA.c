#include<stdio.h>
int main() {
float a,b,c,d;
scanf("%f %f %f %f", &a, &b, &c, &d);
printf("%.2f\n", a+b+c+d/4);
return 0;
}