#include <stdio.h>
int main() {
	int n1, n2, n3, n4;

	scanf("%d %d %d %d", &n1, &n2, &n3, &n4);

	printf("%.2f\n", (float)(n1+n2+n3+n4)/4);

	return 0;
}