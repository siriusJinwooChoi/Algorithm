#include <stdio.h>
int main(void)
{
	int num1, num2, num3, num4;
	int result=0;

	scanf("%d %d %d %d", &num1, &num2, &num3, &num4);

	printf("%.2f", (num1+num2+num3+num4)/4.0);

	return 0;
}