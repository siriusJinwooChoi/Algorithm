#include <iostream>
#include <stdio.h>
int main()
{
    int a=0,b=0,c=0,d=0;
    double sum=0,avg=0;
    
    scanf("%d%d%d%d",&a,&b,&c,&d);
    sum=a+b+c+d;
    avg=(sum/4);
    printf("%.2f",avg);
    
    return 0;
    
    
  
}
