#include <stdio.h>

int main(){
	int n1,n2,n3,n4;
	
	scanf("%d %d %d %d", &n1, &n2, &n3, &n4);
	
	printf("%.2lf", (double)(n1+n2+n3+n4)/(double)4);
	
	return 0;
}