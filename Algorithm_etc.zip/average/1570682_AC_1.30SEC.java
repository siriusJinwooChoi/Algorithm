import java.util.Scanner;
public class  Main
{
   public static void main(String[] args){
      Scanner keyboard = new Scanner(System.in);

      int a,b,c,d;

      a = keyboard.nextInt();
      b = keyboard.nextInt();
      c = keyboard.nextInt();
      d = keyboard.nextInt();

      System.out.println((float)(a+b+c+d)/4);
   }
}