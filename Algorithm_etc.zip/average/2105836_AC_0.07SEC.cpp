#include<stdio.h>

int main(void)
{
	int x,y,z,w;
	float average;

	scanf("%d %d %d %d",&x,&y,&z,&w);

	average = ((float)x+y+z+w)/4;

	printf("%0.2f",average);

	return 0;
}