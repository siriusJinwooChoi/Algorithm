#include<iostream>
#include<cstdio>
using namespace std;

int main()
{
	double n1 = 0, n2 = 0,n3 =0, n4 =0;
	double sum = 0;
	double aver = 0;
	cin >> n1 >> n2 >>n3>>n4;
	sum = n1 + n2 + n3 + n4;
	aver = sum / 4;
	printf("%.2lf \n",aver);
	return 0;
}