/*
 * average.cpp
 *
 *  Created on: 2014. 3. 13.
 *      Author: mountainHufs
 */
#include <iostream>

using namespace std;

int main(){

	double a, b, c, d;

	cin >> a >> b >> c >> d;

	cout << fixed;
	cout.precision(2);

	cout << (a+b+c+d)/4 << endl;
}


