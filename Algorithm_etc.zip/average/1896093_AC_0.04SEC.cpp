#include <iostream>
int main(){
float a,b,c,d;
std::cin>>a>>b>>c>>d;
printf("%.2f",(a+b+c+d)/4);
}