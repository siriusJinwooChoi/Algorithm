
// �⺻����/op
#include <stdio.h>
#include <iostream>

int main()
{
	//int a,b,c;
	//scanf("%d %d",&a,&b);
	//if(a<=1000 && b<=1000)
	/*{
	//c=a+b;
	//printf("%d+%d=%d\n",a,b,c);
	//c=a-b;
	//printf("%d-%d=%d\n",a,b,c);
	//c=a*b;
	//printf("%d*%d=%d\n",a,b,c);
	//c=a/b;
	//printf("%d/%d=%d\n",a,b,c);
	//c=a%b;
	//printf("%d\%%%d=%d\n",a,b,c);
	//=======================================
	}*/
	//else
	//{
	//	return 0;
	//	}
	
	
	float a,b,c,d,e;
	scanf("%f %f %f %f",&a,&b,&c,&d);
	e=((a+b+c+d)/4.0);
	printf("%.2f\n",e);


}
