#include<stdio.h>

int main()
{
	int a, b, c, d, sum = 0;
	double average = 0.0;
	scanf("%d %d %d %d", &a, &b, &c, &d);

	sum = a + b + c + d;
	average =  sum/4.0;

		printf("%.111lf\n", average);
}