#include <iostream>
#include <string>
using namespace std;

// 1 2 1 1 0
int main(){

	string n = "";
	string answer = "";
	char bef = '?';
	int cnt = 1;

	while(1){
		string temp;
		cin >> temp;
		if(temp == "0"){
			break;
		}
		n += temp;
	}
	

	for(int i = n.length()-1; i >= 0; i--){
		if(bef != n[i]){
			bef = n[i];
			if(i == n.length()-1) {
				answer += n[i];
			} else {
				char tp = cnt+'0';
				string tps = " ";
				tps = tp + tps ;
				answer = tps  + n[i] + " " + answer;
				cnt = 1;
			}
		} else {
			cnt ++;
		}
	}
	char tp = cnt+'0';
	string tps = " ";
	tps = tp + tps ;
	answer = tps + answer;

	cout << answer;
	

}