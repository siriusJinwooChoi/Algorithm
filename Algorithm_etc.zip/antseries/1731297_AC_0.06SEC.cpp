#include<iostream>
using namespace std;

int main(){
	int a, k=-1, num;
	int arr[50] = { 0 };
	while (1){
		cin >> a;
		if (a == 0)break;
		else{
			arr[++k] = a;
		}
	}
	num = arr[0];
	int cnt = 0;
	for (int i = 0; i < k + 1; ){
		if (num == arr[i]){
			cnt++;
			i++;
			if (i == k + 1){
				cout << cnt << " " << num << " " << endl;
			}
		}
		else{
			cout << cnt << " " << num << " ";
			num = arr[i];
			cnt = 0;
			continue;
		}
	}
}