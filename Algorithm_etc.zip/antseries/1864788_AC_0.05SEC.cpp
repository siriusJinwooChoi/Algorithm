#include <iostream>
using namespace std;

int main (void){
	int count = 0;
	int result = 0;
	int input[41] ={0,};

	for (int i=0 ; ; i++){
		cin >> input[i];
		// ���ӵǴ� �� (count ����)
		if((input[i] == input[i-1]) || (i==0)){
			count++;
			result = input[i];
		}
		// ���ӵ��� �ʴ� �� (��� & �ʱ�ȭ)
		else if(input[i] != input[i-1]){
			cout << count << " " << result << " ";
			result = 0;
			count = 1;
			result = input[i];
		}			
		if(input[i] == 0) break;
	}	

	return 0;
}