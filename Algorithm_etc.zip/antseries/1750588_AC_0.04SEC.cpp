#include <iostream>
#include <string>
using namespace std;

// 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5 5
int main(){

	string n = "";
	string answer = "";
	char bef = '?';
	int cnt = 1;

	while(1){
		string temp;
		cin >> temp;
		if(temp == "0"){
			break;
		}
		n += temp;
	}

	for(int i = n.length()-1; i >= 0; i--){
		if(bef != n[i]){
			bef = n[i];
			if(i == n.length()-1) {
				answer += n[i];
			} else {
				string tps = " ";
				if(cnt < 10){
					char tp = cnt+'0';
					tps += tp ;
				} else {
					int n1, n2;
					n1 = cnt/10;
					n2 = cnt%10;
					char tp1 = n1+'0';
					char tp2 = n2+'0';
					tps += tp1;
					tps += tp2 ;
				}
				answer = n[i]  + tps + " " + answer;
				cnt = 1;
			}
		} else {
			cnt ++;
		}
	}
	string tps = "";
	if(cnt < 10){
		char tp = cnt+'0';
		tps += tp ;
	} else {
		int n1, n2;
		n1 = cnt/10;
		n2 = cnt%10;
		char tp1 = n1+'0';
		char tp2 = n2+'0';
		tps += tp1;
		tps += tp2 ;
	}
	answer = tps + " " + answer;

	cout << answer;
	

}