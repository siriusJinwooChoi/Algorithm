#include<iostream>
using namespace std;
int main(){
	int memo[1001]={0,};
	int i,N;
	cin>>N;
	for(i=1;i<=N;i++){
		memo[i]=memo[i-1]+i;
	}
	cout<<memo[N]<<endl;
}