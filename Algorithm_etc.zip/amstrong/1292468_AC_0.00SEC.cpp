#include <iostream>
using namespace std;

int main()
{
	int a, b, c, i;
	for(int j=100 ; j<999 ; j++)
	{
		i = j;
		a = i/100;
		i -= a*100;
		b = i/10;
		i -= b*10;
		c = i;
		if(j == a*a*a + b*b*b + c*c*c)
			cout << j << endl;
	}
}