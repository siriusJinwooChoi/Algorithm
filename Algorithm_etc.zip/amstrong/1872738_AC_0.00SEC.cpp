#include <iostream>
using namespace std;

int main(void){
	
	for (int i=100; i<1000; i++){
		int first = (i%100)%10;
		int second = (i%100)/10;
		int third = i/100;
		if(first*first*first + second*second*second + third*third*third == i) cout << i << endl;
	}

	return 0;
}