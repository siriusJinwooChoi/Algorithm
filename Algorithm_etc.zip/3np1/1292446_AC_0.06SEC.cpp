#include <iostream>
using namespace std;

int main()
{
	int num, flag=1;
	cin >> num;
	while(flag)
	{
		cout << num << " ";
		if(num==1)
		{
			break;
		}
		if(num%2==0)	num/=2;
		else			num = 3*num + 1;
	}
}