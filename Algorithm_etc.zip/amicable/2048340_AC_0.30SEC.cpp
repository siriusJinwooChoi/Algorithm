#include<stdio.h>

int main(void)
{
   int a;
   int i;
   int j;
   int k;
   int sum1;
   int sum2;
   
   scanf("%d", &a);
   
   for(i=1;i<=a;i++)
   {
      sum1=0;
     sum2=0;

      for(j=1;j<=i/2;j++)
      {
           if(i%j==0)
           
              sum1+=j;
         }

     for(k=1;k<=(sum1)/2;k++)
     {
        if(sum1%k==0)
           sum2+=k;
     }
     
     if(sum2==i)
     {
        if(sum1<sum2)
           printf("%d %d\n", sum1, sum2);
        
     }
                
      }
}