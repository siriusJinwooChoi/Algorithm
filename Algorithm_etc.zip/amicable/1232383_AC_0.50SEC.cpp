#include <iostream>
using namespace std;

int yak(int n) {
	int result = 0;
	int count = 1;
	while(count < n) {
		if(n % count == 0) {
			result = result + count;
		}
		count++;
	}
	return result;
}

int main() {
	int n;
	cin >> n;

	int num = 2;
	bool chul = false;
	while(num < n) {
		int first = yak(num);
		int last = yak(first);
		if(num == last) {
			if(first > last) {
				cout << last << " " << first <<endl;
			}
		}
		num++;
	}
}