#include <iostream>

using namespace std;

int main(){
	int m, sum = 1, i = 1;

	cin >> m;

	while (m != sum){
		i++;
		sum += i;
	}

	cout << i << endl;
}