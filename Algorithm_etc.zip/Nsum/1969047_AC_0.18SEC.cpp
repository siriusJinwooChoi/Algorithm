#include <iostream>

using namespace std;

int main() {
	int m, i;

	cin >> m;

	int result;

	m = m * 2;

	for (int i = 1; i <= 100; i++) {
		if (i*(i + 1) == m) {
			result = i;
		}
	}

	cout << result << "\n";
}
