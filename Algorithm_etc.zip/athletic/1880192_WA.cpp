#include <stdio.h>

int arr[20]={0};

void match(int k, int oneNum, int zeroNum, int count){
	if(k == oneNum && oneNum > zeroNum){
		for(int i=0;i<count;i++){
			if(arr[i] == 0){
				printf("%c",'X');
			}else{
				printf("%c",'O');
			}
		}
		printf("\n");
		return;
	}

	if(count > 2*k-1)
		return;

	arr[count] = 1;
	match(k,oneNum+1,zeroNum,count+1);

	arr[count] = 0;
	match(k,oneNum,zeroNum+1,count+1);


}

int main(){
	int k;
	scanf("%d",&k);

	match(k,0,0,0);

}