#pragma warning(disable : 4996)
#include<stdio.h>
#include<iostream>
using namespace std;

int win_cnt;
int now_win = 0;
char data[30] = { 0, };
void process(int win_cnt, int now_win, int x_cnt, int position);
int cnt_jae = 0;
int main(){
	cin >> win_cnt;
	process(win_cnt, 0, 0,1);
} 

void process(int win_cnt, int now_win, int x_cnt,int position){
	cnt_jae++;
	if (win_cnt == x_cnt){ return; }
	if (win_cnt == now_win){
		for (int i = 1; i < position; i++){
			cout << data[i];
		}
		cout << endl;
		return;
	}
	if (data[position] != 'o'&&data[position]!='x'){
		data[position] = 'o';
		now_win += 1;
  		process(win_cnt, now_win, x_cnt,position + 1);
	}
	
	if (data[position] == 'o'){
		data[position] = 'x';
		//x_cnt += 1;
		now_win -= 1;
		process(win_cnt, now_win, x_cnt+1, position + 1);
	}
	if (data[position] == 'x'){
		data[position] = '\n';
		x_cnt -= 1;
		
	}
}