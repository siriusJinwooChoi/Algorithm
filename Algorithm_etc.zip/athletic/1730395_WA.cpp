#include <iostream>

using namespace std;

int n;
int arr[100]={0};
int count=0;

void win(int c_index, int w_cnt, int l_cnt)
{
	//Ż������
	if(w_cnt == n){
		for(int i=0;i<c_index;i++){
			if(arr[i] == 1){
				cout << "o";
			}else{
				cout << "x";
			}
		}
		count++;
		cout << endl;
		return;
	}

	if(c_index >= n * 2) return;
	if(l_cnt >= n) return;

	arr[c_index] = 1;
	win(c_index+1,w_cnt+1,l_cnt);
	arr[c_index] = 0;
	win(c_index+1,w_cnt,l_cnt+1);

}
int main()
{
	
	cin >> n;

	win(1,0,0);
	cout << "total "<< count << " case(s)" << endl;

}