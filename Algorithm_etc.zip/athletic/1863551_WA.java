import java.util.Scanner;

public class Main {

	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
			
			int n = sc.nextInt();
			int win_count = 0, loose_count=0;
			String s = "";
			win(n, win_count, loose_count, s);
			loose(n, win_count, loose_count, s);
	}
	
	public static void win(int n, int win_count, int loose_count, String s){
		//��������
		if(win_count==n){
			System.out.println(s);
			return;
		}
		else{
			win_count++;
			s += "O";
			win(n, win_count, loose_count,s );
			loose(n, win_count, loose_count,s);
		}
	}
	public static void loose(int n, int win_count, int loose_count, String s){
		//��������
				if(loose_count==(n-1) || win_count == n){
					return;
				}
				else{
					loose_count++;
					s += "X";
					win(n, win_count, loose_count,s );
					loose(n, win_count, loose_count,s);
				}
	}
}