#include <iostream>
using namespace std;

char arr[20];
int n;
int case_count = 0;

void play(int current_idx, int win_num, int lose_num){
	if (win_num == n){
		for (int i = 0; i < current_idx; i++){
			cout << arr[i];
		}
		cout << endl;
		case_count++;
		return;
	}
	if (lose_num >= n) return;
	if (current_idx >= n * 2) return;
	arr[current_idx] = 'o';
	play(current_idx + 1, win_num + 1, lose_num);
	arr[current_idx] = 'x';
	play(current_idx + 1, win_num, lose_num + 1);
}

int main(){
	cin >> n;
	play(0, 0, 0);
	cout << "total " << case_count << " case(s)" << endl;

	return 0;
}