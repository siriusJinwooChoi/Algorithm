#include <iostream>
#include <string>
using namespace std;
int n;
int total=0;
void play(string win, int count){
	string tmp=win;
	int tmpc=count;
	if(count==n|| win.size()>=n+n-1){
		if(win.size()-count<count){cout<<win<<endl;total++;}
		return ;
	}
	win+="o";  count++;
	play(win, count);
	win=tmp; count=tmpc;
	win+="x";
	play(win,count);
}
int main(){
	string str="";
	cin>>n;
	play(str,0);
	cout<<"total "<<total<<" "<<"case(s)"<<endl;
	return 0;
}