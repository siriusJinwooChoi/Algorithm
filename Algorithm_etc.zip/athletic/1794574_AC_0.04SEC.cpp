#include<iostream>
#include<string>
using namespace std;
int count=0;  
int st_num(string num);
string num_st(int num);
int two(int num);   
int number=0;
int function(int N,int K,int count,int check,string str);
int main(){

	 int N;
	 cin>>N;
	 function(N,0,0,0,"");
	 cout<<"total "<<number<<" case(s)";
	 return 0;
}

int function(int N,int K,int count,int check,string str){
 //N�̰ܾ��ϴ�Ƚ�� , K ���� Ƚ��, count ���Ƚ�� ,check �̱� Ƚ��
	if(check==N){
		cout<<str<<endl;
		number++;
		return 0;
	}else if(K==N){
		return 0;
	}
	//�̰��� ���
	function(N,K,count+1,check+1,str+"o");
	//�������
	function(N,K+1,count+1,check,str+"x");
}
 int two(int num){
	if(num==0){
		return 1;
	}else{
		return 2*two(num-1);
	}
}/*
int st_num(string num){
	int size=num.size();
	int number=0;
	for(int i=0,j=size-1;i<size;i++,j--){
		number+=(num.at(i)-'0')*ten(j);
	}
	return number;
}
string num_st(int num){
	string st="";
	int num_c=num;
	int n_c=0;
	while(1){
		if(num_c/10==0)break;
		num_c/=10;
		n_c++;
	}
	for(int i=n_c;i>=0;i--){
		int number=num/ten(i);
		num-=number*ten(i);
		st+=number+'0';
	}
	return st;
}
 */