#include <stdio.h>

void athletic(int,int,int,int,char*);
int N;

int main(){
	char result[20];
	scanf("%d",&N);
	athletic(N,0,N-1,0,result);
	return 0;
}

void athletic(int n,int index,int k,int count,char* buf){
	if(n==0){
		if(count<N){
			int s = count;
			while(s<N){
				buf[index]='o';
				index++;
				s++;
			}
			buf[index]='\0';
			printf("%s\n",buf);
			while(s!=count){
				index--;
				buf[index]='\0';
				s--;
			}
			return ;
		}
		else{
			buf[index]='\0';
			printf("%s\n",buf);
			return ;
		}
	}
	int i;
	for(i=0; i<2; i++){
		if(i==0){
			buf[index]='o';
			index++;
			count++;
		//	k--;
			athletic(n-1,index,k,count,buf);
			//k++;
			count--;
			index--;
			buf[index]='\0';
		}
		else if(i==1 && k>0){
			buf[index]='x';
			index++;
			k--;
			athletic(n-1,index,k,count,buf);
			k++;
			index--;
			buf[index]='\0';
		}
	}
}

