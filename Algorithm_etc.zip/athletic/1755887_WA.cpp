
#include<iostream>
using namespace std;

int n;
int res[31];
int howManyWin(int res_cnt) {
	int cnt = 0;
	for (int i = 0; i < res_cnt; i++){
		if (res[i] == 1)
			cnt++;
	}
	return cnt;
}
void win(int now) {
	int win_times = howManyWin(now);
	if (now - win_times >= n)
		return;
	if (win_times == n) {
		for (int i = 0; i < now; i++) {
			if (res[i] == 0) cout << "X";
			else cout << "O";
		}
		cout << endl;
		return;
	}

	res[now] = 1;
	win(now + 1);
	res[now] = 0;
	win(now + 1);
}
int main() {
	cin >> n;
	win(0);
	return 0;
}