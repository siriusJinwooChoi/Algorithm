#include <stdio.h>

int N,total;
char wl[2]={'o','x'};
void calc(int,int,int,int,char*);

int main(){
	int n;
	char buf[30];
	scanf("%d",&N);
	total = 0;
	n = N+N-1;
	calc(n,0,0,0,buf);
	printf("total %d case(s)\n",total);
	return 0;
}

void calc(int n,int index,int xcnt,int count,char* buf){
	if(n==0 || count==N){
		total++;
		buf[index]='\0';
		printf("%s\n",buf);
		return ;
	}
	int i;
	buf[index]='\0';
	for(i=0; i<2; i++){
		if(i==0){
			buf[index]=wl[i];
			index++;
			count++;
			calc(n-1,index,xcnt,count,buf);
			count--;
			index--;
			buf[index]='\0';
		}
		if(i==1&&xcnt<N-1){
			buf[index]=wl[i];
			index++;
			xcnt++;
			calc(n-1,index,xcnt,count,buf);
			xcnt--;
			index--;
			buf[index]='\0';
		}
	}
}