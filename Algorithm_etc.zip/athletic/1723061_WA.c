#include <stdio.h>

int n, cnt;

int print(int win, int lose, char *str)
{
	int i;
	char str2[20];

	for(i=0; i<20; i++)	str2[i] = str[i];

	if (win >= n)
	{
		cnt++;
		printf("%s\n",str);
		return;
	}
	
	str2[win+lose] = 'o';
	str2[win+lose+1] = 0;

	print(win+1,lose,str2);
	
	if(lose<n-1)
	{
		str2[win+lose] = 'x';
		str2[win+lose+1] = 0;

		print(win, lose+1, str2);
	}
}

int main()
{
	char str[20] = {0,};
	scanf("%d",&n);
	print(0,0, str);
}