#include <iostream>
using namespace std;

int tempCount = 0;



int N, K;
char arr[50];
int totalCount = 0;
void rs(int currentN, int vic, char* arr){
	if (vic == N){
		for (int i = 0; i < currentN; ++i)
		cout << arr[i];
		cout << endl;
		totalCount++;
		return;
	}
	if ((currentN != 0 && vic != 0) && N * 2 - 2 < currentN || (vic == 0 && currentN == N)){
		return;
	}
	arr[currentN] = 'o';
	rs(currentN + 1, vic + 1, arr);
	arr[currentN] = 'x';
	rs(currentN + 1, vic, arr);
	return;
}



int main()
{
	cin >> N;

	int temp = 0;
	int vicTemp = 0;
	rs(temp, vicTemp, arr);
	cout << "total " << totalCount << " case(s)" << endl;
	return 0; /* �ݵ�� return 0���� ���ּž��մϴ�. */
}
