#include <iostream>
#include <string>
using namespace std;

int go(int w, int l, string r)
{
	if(w==0)
	{
		cout << r << endl;
		return 1;
	}
	if(l==0) return 0;

	r.push_back('o');
	int ret = go(w-1,l,r);
	r.erase(r.end()-1);
	
	r.push_back('x');
	ret += go(w,l-1,r);


	return ret;
}

int main()
{
	int n;
	string r;
	cin >> n;

	cout << "total "<<go(n,n,r)<<"case(s)"<<endl;

	return 0;
}