#include <iostream>
using namespace std;

int n;
int tWin;
char arr[20];

void match(int pos, int win_c, int lose_c){

	if(pos>=2*n){
		return;
	}
	if(win_c==3){
		for(int i=0; i<pos; i++){
			cout<<arr[i];
		}
		cout<<endl;
		return;
	}
	if(n == lose_c){
		return;
	}

	arr[pos]='o';
	win_c++;
	match(pos+1,win_c,lose_c);
	arr[pos]='x';
	win_c--;
	lose_c++;
	match(pos+1,win_c,lose_c);
}

int main(){
	for(int i=0; i<20; i++){
		arr[i]=0;
	}

	cin>>n;

	match(0,0,0);

	return 0;
}