#include<iostream>
#include<vector>
using namespace std;

vector<char> stack;
int result=0;

void athletic(int o,int x, int n){

	if(o==n||x==n){

		if(x!=n){
			for(int i=0;i<stack.size();i++){
				cout<<stack.at(i);
			}
			cout<<endl;
			result++;
		}
		

	}else{
		stack.push_back('o');
		athletic(o+1,x,n);
		stack.pop_back();

		stack.push_back('x');
		athletic(o,x+1,n);
		stack.pop_back();


	}

}


int main(){

	int count;

	cin>>count;

	athletic(0,0,count);
	cout<<"total "<<result<<"case(s)";

	return 0;
}