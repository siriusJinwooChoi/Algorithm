#include<stdio.h>

int n, cnt;
char print[100];
int max, total;

void ps(int a)
{
	int i;
	if(cnt>=max)
		return;

	if(a==n)
	{
		for(i=0; i<cnt; i++)
			printf("%c",print[i]);
		printf("\n");
		total++;
		return;
	}

	print[cnt++]='o';
	ps(a+1);
	cnt--;

	print[cnt++]='x';
	ps(a);
	cnt--;
}

int main(void)
{
	scanf("%d",&n);

	max = 2*n;

	ps(0);

	printf("total %d case(s)\n",total);

	return 0;
}