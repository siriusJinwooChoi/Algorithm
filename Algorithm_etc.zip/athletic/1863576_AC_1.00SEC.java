import java.util.Scanner;

public class Main {
	static int count = 0;
	
	public static void main(String args[]){
		Scanner sc = new Scanner(System.in);
	
			int n = sc.nextInt();
			int win_count = 0, loose_count=0;
			String s = "";
			win(n, win_count, loose_count, s);
			loose(n, win_count, loose_count, s);
			System.out.println("total "+ count +" case(s)");
	}
	
	public static void win(int n, int win_count, int loose_count, String s){
		//��������
		if(win_count==n){
			System.out.println(s);
			count++;
			return;
		}
		else{
			win_count++;
			s += "o";
			win(n, win_count, loose_count,s);
			loose(n, win_count, loose_count,s);
		}
	}
	public static void loose(int n, int win_count, int loose_count, String s){
		//��������
				if(loose_count==(n-1) || win_count == n){
					return;
				}
				else{
					loose_count++;
					s += "x";
					win(n, win_count, loose_count,s);
					loose(n, win_count, loose_count,s);
				}
	}
}