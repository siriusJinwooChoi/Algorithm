#include <stdio.h>
#include <stdlib.h>

typedef struct NODE{
	struct NODE* left;
	struct NODE* right;
	int win;
	int lose;
	char arr[2000];
}NODE;

int w,cnt;
NODE start = {0,0,0,0,0};
NODE *s1,s2,s3;

NODE* Create_NODE_win(NODE *s)
{
	int i;
	NODE * new_NODE;
	new_NODE = (NODE*)malloc(sizeof(NODE));

	new_NODE->win = s->win+1;
	new_NODE->lose = s->lose;

	for(i=0; i<(s->win+s->lose); i++)
	{
		new_NODE->arr[i] = s->arr[i];
	}
	new_NODE->arr[i] = 'o';
	new_NODE->arr[i+1] = 0;

	return new_NODE;
}

NODE* Create_NODE_lose(NODE *s)
{
	int i;
	NODE * new_NODE;
	new_NODE = (NODE*)malloc(sizeof(NODE));

	new_NODE->win = s->win;
	new_NODE->lose = s->lose+1;

	for(i=0; i<(s->win+s->lose); i++)
	{
		new_NODE->arr[i] = s->arr[i];
	}
	new_NODE->arr[i] = 'x';
	new_NODE->arr[i+1] = 0;

	return new_NODE;
}

void Make_Tree(NODE *s)
{
	int i;

	if(s->win >= w)
	{
		cnt++;
		printf("%s\n",s->arr);
		return;
	}

	s->left = Create_NODE_win(s);
	Make_Tree(s->left);

	if(s->lose < w-1)
	{
		s->right = Create_NODE_lose(s);
		Make_Tree(s->right);
	}
}

int main()
{
	int i,j,k;

	scanf("%d", &w);

	Make_Tree(&start);

	printf("total %d case(s)",cnt);
}