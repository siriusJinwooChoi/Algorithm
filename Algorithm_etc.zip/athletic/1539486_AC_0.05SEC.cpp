#include <stdio.h>
#include <vector>
using namespace std;

int win;
int count=0;

void printPicked(vector<char>& a) {
	count++;
	for(int i=0; i<a.size(); i++)
		printf("%c", a[i]);
	printf("\n");
}

void game(int n, vector<char>& picked) {
	if(n==0) {
		printPicked(picked);
		return;
	}

	if(picked.size() > 2*win-2)
		return;
	
	picked.push_back('o');
	game(n-1,picked);
	picked.pop_back();
	picked.push_back('x');
	game(n,picked);
	picked.pop_back();
}

int main() {

	vector<char> picked;
	
	scanf("%d", &win);

	game(win, picked);

	printf("total %d case(s)",count);

	return 0;
}