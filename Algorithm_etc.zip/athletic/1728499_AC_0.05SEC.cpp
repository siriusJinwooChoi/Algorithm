#include <iostream>
#include <string>
using namespace std;

int n;
int result;
void athletic(int o, int x, string output){
	if(o==n) {
		cout<<output<<endl;
		result++;
		return;
	}
	if(x==n) return;
	athletic(o+1,x,output+"o");
	athletic(o,x+1,output+"x");
	return;
}
int main(){
	result=0;
	cin>>n;
	athletic(0,0,"");
	cout<<"total "<<result<<" case(s)"<<endl;
	return 0;
}