#include <stdio.h>

void main(){
	int width = 0;
	int height = 0;

	scanf("%d %d",&width, &height);
	printf("%d\n", width*height);
}