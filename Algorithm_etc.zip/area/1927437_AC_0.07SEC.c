#include <stdio.h>

int main(void) {
	int a, b, c;

	scanf("%d %d", &a, &b);
	c = a*b;
	printf("%d\n", c);
}