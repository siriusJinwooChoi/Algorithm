#include <stdio.h>
#include <stdlib.h>

int main(){
	int T;
	int a,b;
	T = 0;
	a = 0;
	b = 0;
	scanf("%d",&T);
	while(T--){
		scanf("%d%d",&a,&b);
		printf("%d\n",a*b);
	}
	return 0;
}
