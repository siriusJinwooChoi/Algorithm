#include <stdio.h>

int main(void) {
	int width, height = 0;

	scanf("%d %d", &width, &height);

	printf("%d\n", width*height);
}