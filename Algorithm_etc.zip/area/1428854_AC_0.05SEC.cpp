#include <iostream>

using namespace std;

int main()
{
	int width,height;

	cin >> width >> height;

	cout << width*height << endl;
	return 0;
}
