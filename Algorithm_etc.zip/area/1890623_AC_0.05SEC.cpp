#include <iostream>
using namespace std;


int main(void){

	int hor, ver;

	cin >> hor >> ver;
	cout << hor*ver << endl;
	return 0;
}