#include <stdio.h>

void main(){
	int w,h;
	scanf("%d %d",&w, &h);
	printf("%d\n", w*h);
}