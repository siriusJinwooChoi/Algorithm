/*
 * area.cpp
 *
 *  Created on: 2014. 3. 13.
 *      Author: mountainHufs
 */
#include <iostream>

using namespace std;

int main(){

	int a;
	int b;
	int s;

	cin >> a >> b;

	s = a*b;

	cout << s << endl;
}


