a,b = map(int,raw_input().split())
print a*b