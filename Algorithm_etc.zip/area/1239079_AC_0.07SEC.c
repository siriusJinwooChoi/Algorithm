#include <stdio.h>

int Input,Result,V,H;
int main(){

	scanf("%d %d", &H,&V);
	Result  =  H * V;

	printf("%d\n", Result);

	return 0;
}