#include<stdio.h>
int a,b;
int input()
{
    scanf("%d%d",&a,&b);
}
int square(int a,int b)
{
    printf("%d",a*b);
}
int main()
{
    input();
    square(a,b);
}