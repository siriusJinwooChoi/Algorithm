#include <stdio.h>
int main(void)
{
	int num1, num2;
	int result=0;

	scanf("%d %d", &num1, &num2);
	result = num1*num2;

	printf("%d", result);

	return 0;
}