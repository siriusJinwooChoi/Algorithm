#include <stdio.h>
#include <iostream>

int main()
{
	int a,b,c;
	scanf("%d %d",&a,&b);
	c=a*b+1;
	printf("%d",c);

}