a,b = map(int,rawinput().split())
print a*b