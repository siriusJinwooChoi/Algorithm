#include <iostream>
#include <algorithm>
using namespace std;
int arr[1000000];
int d[1000000];
int main(){
	int N;

	cin>>N;
	for(int i=0; i<N; i++){
		cin>>arr[i];
		d[i]=1;
	}
	
	for(int i=1; i<=N; i++){
		for(int j=0; j<i; j++){
			if(arr[i]>=arr[j] && d[j]+1>d[i]){
				d[i]=d[j]+1;
			}
		}
	}
	sort(d,d+N);
	cout<<N-d[N-1]<<endl;
	return 0;
}