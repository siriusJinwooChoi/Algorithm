#include <iostream>
using namespace std;
int arr[1000000];
int main(){
	int N;
	int max=1;
	int m=1;
	cin>>N;
	for(int i=0; i<N; i++){
		cin>>arr[i];
		if(i>0 && arr[i]>arr[i-1]){ 
			max++; 
			if(m<=max)m=max;
		}
		else max=1;
	}
	cout<<N-m<<endl;
	return 0;
}