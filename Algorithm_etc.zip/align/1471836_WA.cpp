#include <iostream>
using namespace std;
int arr[1000000];
int main(){
	int N;
	int max=1;
	cin>>N;
	for(int i=0; i<N; i++){
		cin>>arr[i];
		if(i>0 && arr[i]>arr[i-1]) max++;
		else max=1;
	}
	cout<<N-max<<endl;
	return 0;
}