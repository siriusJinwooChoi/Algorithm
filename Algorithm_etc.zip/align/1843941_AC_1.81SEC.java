import java.util.Arrays;
import java.util.Scanner;

public class Main {
    
	public static void main(String arg[]){
		Scanner input = new Scanner(System.in);
		int N = input.nextInt();
		int arr[] = new int[N];
		int d[] = new int[N];
		
		for(int i=0; i<N; i++){
	        arr[i] = input.nextInt();
	        d[i]=1;
	    }
	     
	    for(int i=0; i<N; i++){
	        for(int j=0; j<i; j++){
	            if(arr[i] >= arr[j] && d[j]+1 > d[i]){
	                d[i] = d[j]+1;
	            }
	        }
	    }
	    
	    Arrays.sort(d);
	    System.out.println(N-d[N-1]);
	}
}