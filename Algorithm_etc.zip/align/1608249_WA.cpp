#include <iostream>
using namespace std;
int arr[1000000];
int d[1000000];
int main(){
    int N;
    int max=-1;
    cin>>N;
    for(int i=0; i<N; i++){
        cin>>arr[i];
        d[i]=1;
    }
     
    for(int i=1; i<=N; i++){
        for(int j=0; j<i; j++){
            if(arr[i]>=arr[j] && d[j]+1>d[i]){
                d[i]=d[j]+1;
                if(max<d[i])max=d[i];
            }
        }
    }
    cout<<N-max<<endl;
    return 0;
}