#include <stdio.h>

int main(void) {

	int c, f;

	scanf("%d", &c);

	printf("%.1lf\n", (double)9 / 5 * c + 32);
}