#include <iostream>

using namespace std;

int main()
{
	int a, b, c, d;

	cin >> a;

	printf("%.1f\n", 9/5.0*a+32);
}