#include<stdio.h>
int main(){
int a;
scanf("%d", &a);
printf("%d\n",  9 / 5.0 * a + 32 );
}