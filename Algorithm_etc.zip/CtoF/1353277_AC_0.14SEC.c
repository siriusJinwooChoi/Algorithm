#include <stdio.h>
int main(void)
{
	int temp;
	float F=0;

	scanf("%d", &temp);

	F = (1.8*temp)+32; 

	printf("%.1f", F);

	return 0;
}