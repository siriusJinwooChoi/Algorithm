#include <stdio.h>
int A;
double B;
int main(){
	scanf("%d", &A);

	B = (double)9/5 *A+32;
	printf("%.1f", B);
	return 0;
}