/*
 * CtoF.cpp
 *
 *  Created on: 2014. 3. 13.
 *      Author: mountainHufs
 */

// 9/5 * �����µ� + 32;

#include <iostream>
using namespace std;

int main(){

	double F;
	double C;

	cin >> F;

	C = ( (F*9/5) + 32 );

	cout << fixed;
	cout.precision(1);
	cout << C << endl;
}

