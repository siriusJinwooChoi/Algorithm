#include<stdio.h>
int main() {
float a;
scanf("%f", &a);
printf("%.1f\n", (9 / 5 )* a + 32);
return 0;
}