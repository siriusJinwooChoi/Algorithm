#include<stdio.h>
int main() {
float a, b;
scanf("%f", &a);
b= 9 / (5*a) + 32;
printf("%.1f\n", b);
return 0;
}