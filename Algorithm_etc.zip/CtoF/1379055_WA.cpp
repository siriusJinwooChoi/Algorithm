#include <iostream>
#include <iomanip>
                                                                                                                                                                 
using namespace std;
                  
int main()        
{                 
    float c, f;   
                  
    cin >> c;     
                  
    f = 9.0 / 5 * f + 32;
                  
    cout << fixed << setprecision(1);
    cout << f << endl;
}   