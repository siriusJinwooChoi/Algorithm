#include<stdio.h>
int main(){
int a;
scanf("%d", &a);
printf("%.2f\n",  9/5.0*a + 32 );
}