#include <iostream>

using namespace std;

int main()
{
	double c;
	double f;
	double div=0;
	cin >> c;

	div = (double)9 / 5 ;
	f = div*c+32;
	cout.setf(ios::fixed,ios::floatfield);
	cout.precision(1);
	cout << f << endl;

	
}