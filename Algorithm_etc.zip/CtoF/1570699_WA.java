import java.util.Scanner;
public class  Main
{
   public static void main(String[] args){
      Scanner keyboard = new Scanner(System.in);

      int a,b;

      a = keyboard.nextInt();

      System.out.printf("%3.1f",9 / 5 * a + 32);
   }
}