#include <stdio.h>

void main() {
	int c;
	double f = 0;

	scanf("%d", &c);
	f = (double)9 / 5 * c + 32;

	printf("%.1f", f);
}