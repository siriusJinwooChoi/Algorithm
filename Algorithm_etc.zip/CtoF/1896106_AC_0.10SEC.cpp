#include <iostream>
int main(){
float a;
std::cin>>a;
printf("%.1f",1.8*a+32);
}