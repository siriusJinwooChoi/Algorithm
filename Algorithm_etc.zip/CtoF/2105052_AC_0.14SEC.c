#include <stdio.h>
int main() {
	int n;
	scanf("%d", &n);
	printf("%.1f\n", ((float)9/5)*n+32);

	return 0;
}