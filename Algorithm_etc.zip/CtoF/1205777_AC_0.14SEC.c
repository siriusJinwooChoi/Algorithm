#include <stdio.h>

void main(){
  int c;
  scanf("%d", &c);
  printf("%.1f", 9.0/5.0*(float)c+32.0); 
}