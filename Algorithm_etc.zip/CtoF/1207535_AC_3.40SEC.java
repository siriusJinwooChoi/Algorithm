import java.util.Scanner;


public class Main {
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		float C = sc.nextFloat();
		float F = 1.8f * C + 32.0f;
		String res = String.format("%.1f", F);
		System.out.println(res);
	}
}
