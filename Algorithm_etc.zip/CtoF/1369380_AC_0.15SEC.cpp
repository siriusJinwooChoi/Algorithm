#include <stdio.h>

int main(){
	int a;
	scanf("%d", &a);
	printf("%.1f", (9.0 / 5.0 * a + 32));
}