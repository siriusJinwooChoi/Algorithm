import java.util.Scanner;


public class Main{

	public static void main(String[] args) {
		Scanner scan = new Scanner(System.in);
		int n = scan.nextInt();
		int score[] = new int[1000];
		int sum=0;
		double avg = 0.0;
		
		for(int i=0 ; i < n ; i++) {
			score[i] = scan.nextInt();
			sum += score[i];
		}
		
		avg = (double)sum / n;
		
		int count=0;
		
		for(int i=0 ; i<n ; i++) {
			if(score[i] > avg) {
				count++;
			}
		}
		double bac = (double)count/n*100;
		
		System.out.printf("%.3f",bac);
		System.out.println("%");

	}
}
