#include <iostream>
using namespace std;

int main() {
	int a, d, an;
	cin >> a >> d >> an;

	an = an - a;

	if(an % d == 0)
		cout << (an / d) + 1 <<endl;
	else
		cout << "X" <<endl;
}