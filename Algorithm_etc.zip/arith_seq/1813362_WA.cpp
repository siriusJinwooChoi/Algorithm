#include <iostream>
using namespace std;

int main(void){
	int A, D, X;
	cin >> A >> D >> X;
	if ((X-A) % D == 0) cout << ((X-A) / D) + 1 << endl;
	else cout << "x" << endl;
}