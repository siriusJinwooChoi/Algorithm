#include<iostream>
#include<string.h>
using namespace std;

int main(){
	char s[100000], t[100000];	
	int count = 0;
	for (int i = 0; i < 1000; i++){
		cin >> s >> t;
		count = 0;
		if (s[0] == 'E'&&s[1] == 'O'&&s[2] == 'F' || t[0] == 'E'&&t[1] == 'O'&&t[2] == 'F') break;
		else{
			for (int i = 0; i < strlen(s); i++){
				for (int j = 0; j < strlen(t); j++){
					if (s[i] == t[j]){
						count++;						
						s[i] = -1;
						for (int h = j; h > -1; h--){
							t[h] = -1;
						}
						break;
					}
					else continue;
				}
			}
			if (count == strlen(s)) cout << "YES" << endl;
			else cout << "NO" << endl;
		}

	}
}