import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            String strS = scan.next();
            String strT = scan.next();
            
            if(true == strS.equals("EOF"))
            	break;
            
            boolean bResult =  true;
            
            int nCheckIndex = 0;
            boolean arResult[] =  new boolean[strS.length()];
            for(int j=0; j<strT.length(); j++)
            {
            	if(nCheckIndex >= strS.length())
            	{
            		break;
            	}
            	
            	if(strS.charAt(nCheckIndex) == strT.charAt(j))
            	{
            		arResult[nCheckIndex++] = true;
            	}
            }
            
            for(int j=0; j<strS.length(); j++)
            {
            	if(arResult[j] == false)
            	{
            		bResult = false;
            	}
            }
            
            if(true == bResult)
            	System.out.println("Yes");
            else
            	System.out.println("No");
        }
	}
}
