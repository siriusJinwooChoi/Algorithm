#include <iostream>
#include <string>
using namespace std;

string s, t;
int main()
{
	int j=0;
	while(cin >> s && cin >> t)
	{
		j=0;
		for(int i=0 ; i<t.length() ; i++)
			if(s[j] == t[i])
				j++;
		if(s.length() == j)
			cout << "Yes" << endl;
		else cout << "No" << endl;
	}
}