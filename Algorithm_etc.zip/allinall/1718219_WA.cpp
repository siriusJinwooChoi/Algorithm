#include <iostream>
#include <string.h>
using namespace std;

char s[100010];
char t[100010];

int main()
{

	int length=0;
	int start=0;
	int cnt=0;

	while(scanf("%s",s)!=EOF){
		cin >> t;
		
		int j=0;
		length = strlen(t);

		while(s[j]!=NULL){
			for(int i=start;i<length;i++){
				if(s[j] == t[i]){
					start= i;
					cnt++;
					break;
				}
			}
			j++;
			
		}

		if(cnt == strlen(s)){
			cout << "Yes" << endl;
		}else{
			cout << "No" << endl;
		}

		cnt=0;
		start = 0;
	}
}