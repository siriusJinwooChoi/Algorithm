#include<iostream>
#include<string.h>
using namespace std;

int main(){
	
	int count = 0;
	while (1){
		char s[100000], t[100000];
		cin >> s;
		if (s[0] == 'E'&&s[1] == 'O'&&s[2] == 'F') break;
		cin >> t;		
		if (t[0] == 'E'&&t[1] == 'O'&&t[2] == 'F') break;
		
		else{
			count = 0;
			int slen = strlen(s);
			int tlen = strlen(t);
			for (int i = 0; i < slen; i++){
				for (int j = 0; j < tlen; j++){
					if (s[i] == t[j]){
						count++;						
						s[i] = -1;
						for (int h = j; h > -1; h--){
							t[h] = -1;
						}
						break;
					}
					else continue;
				}
			}
			if (count == slen) cout << "Yes" << endl;
			else cout << "No" << endl;
		}

	}
}