#include<iostream>
#include<string.h>
using namespace std;

int main(){
	char s[100001], t[100000];
	int count = 0;

	while (s[0] != 'E'&&s[1] != 'O'&&s[2] != 'F'){
		
		cin >> s;
		if (s[0] == 'E'&&s[1] == 'O'&&s[2] == 'F') break;
		cin >> t;
		if (t[0] == 'E'&&t[1] == 'O'&&t[2] == 'F') break;

		else{
			count = 0;
			int slen = strlen(s);
			int tlen = strlen(t);
			int i = 0;
			for (int j = 0; j < tlen; j++){
				if (s[i] == t[j]){
					i++;
					/*s[i] = -1;
					for (int h = j; h > -1; h--){
						t[h] = -1;
					}
					break;*/
				}
				else continue;
			}

			if (i == slen) cout << "Yes" << endl;
			else cout << "No" << endl;
		}

	}
}