import java.util.Scanner;


public class Main 
{
	public static void main(String[] args) 
	{
        Scanner scan = new Scanner(System.in);
        while(true)
        {
            String strS = scan.next();
            String strT = scan.next();
            
            if(true == strS.equals("EOF"))
            	break;
            
            boolean bResult =  strT.contains(strS);
            if(true == bResult)
            	System.out.println("YES");
            else
            	System.out.println("NO");
        }
	}
}
