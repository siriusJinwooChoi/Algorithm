#include <iostream>
using namespace std;
 
int main()
{
    char a[100001],b[100001];
    int l,k,j;
    while(true)
    {
        l=0; k=0;j=0;
        cin>>a>>b;
        if(cin.eof()) break;
        while(b[l]!=NULL) l++;
        while(a[j]!=NULL) j++;
        for(int i=0;i<l;i++)
        {
            if(a[k]==b[i]) k++;
        }
        if(k==j) cout << "Yes"<<endl;
        else cout << "No"<<endl;
    }
}