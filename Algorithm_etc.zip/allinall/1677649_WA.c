#include <stdio.h>

int main()
{
	char s[100010], t[100010];
	int i, j;

	scanf("%s %s", s, t);

	for (i = 0, j = 0; '\0' != s[i] && '\0' != t[j]; ++j) {
		if (s[i] == t[j])
			++i;
	}

	if ('\0' == s[i])
		printf("Yes\n");
	else
		printf("No\n");
}