#include <stdio.h>

int main(void)
{
	int n, i, j;
	int num[4], temp, index, cnt=0;
	int max[4], min[4], check[4];
	int max_num, min_num;

	scanf("%d",&n);

if(n==6174)
{
printf("0\n");
return 0;
}

	while (1)
	{
		for (i = 0; i < 4; i++)
			max[i] = check[i] = 0;

		num[0] = n / 1000;
		num[1] = (n / 100) % 10;
		num[2] = (n / 10) % 10;
		num[3] = (n) % 10;

		for (i = 0; i < 4; i++)
		{
			temp = -1;
			for (j = 0; j < 4; j++)
			{
				if (check[j]==0 && temp < num[j])
				{
					temp = num[j];
					index = j;
				}
			}
			check[index] = 1;
			max[i] = num[index];
		}

		max_num = max[0] * 1000 + max[1] * 100 + max[2] * 10 + max[3];

		for (i = 0; i < 4; i++)
			min[i] = check[i] = 0;

		for (i = 0; i < 4; i++)
		{
			temp = 99999;
			for (j = 0; j < 4; j++)
			{
				if (check[j] == 0 && temp > num[j])
				{
					temp = num[j];
					index = j;
				}
			}
			check[index] = 1;
			min[i] = num[index];
		}

		min_num = min[0] * 1000 + min[1] * 100 + min[2] * 10 + min[3];

		if (max_num - min_num == 6174)
		{
			printf("%d\n",cnt+1);
			break;
		}
		cnt++;

		n = max_num - min_num;
	}

	return 0;
}