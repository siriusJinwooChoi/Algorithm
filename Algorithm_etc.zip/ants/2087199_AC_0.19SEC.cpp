#include<stdio.h>

int main(void)
{
	int l,n, i, min=0, max=0, data, temp;

	scanf("%d %d",&l,&n);

	for(i=0; i<n; i++)
	{
		scanf("%d",&data);

		temp = l-data;
		if(temp>data)
		{
			if(data>min)
				min = data;
			if(temp>max)
				max = temp;
		}
		else
		{
			if(temp>min)
				min =temp;
			if(data>max)
				max =data;
		}
	}
	printf("%d %d\n",min, max);

	return 0;
}