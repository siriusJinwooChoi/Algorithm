#include <iostream>
using namespace std;
int sum[3] = { 0, };
int main()
{
	int n;
	for (int i = 0; i < 7; ++i) {
		cin >> n;
		
		if (n/10 == 0) {
			sum[0] += n;
		} else if (n / 100 == 0) {
			sum[1] += n;
		} else if (n / 1000 == 0) {
			sum[2] += n;
		}
	}

	cout << sum[0] << ' ' << sum[1] << ' ' << sum[2];
}