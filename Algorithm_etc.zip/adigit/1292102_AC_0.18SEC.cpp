#include <iostream>
using namespace std;

int main()
{
	int num, sum0=0, sum1=0, sum2=0;
	for(int i=0 ; i<7 ; i++)
	{
		cin >> num;
		if(num > 99) sum2 += num;
		else if(num > 9) sum1 += num;
		else sum0 += num;
	}
	cout << sum0 << " " << sum1 << " " << sum2 << endl;
}