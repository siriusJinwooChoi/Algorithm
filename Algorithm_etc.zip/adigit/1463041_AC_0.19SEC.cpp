#include <iostream>

using namespace std;

int main(){
	int a = 0, b = 0, c = 0;
	int input;

	for (int i = 0; i < 7; i++){
		cin >> input;

		if (input < 10)
			a += input;
		else if (input < 100)
			b += input;
		else
			c += input;
	}

	cout << a << " " << b << " " << c << endl;
}