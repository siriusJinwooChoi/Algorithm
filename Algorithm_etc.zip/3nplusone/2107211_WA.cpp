#include <stdio.h>

int arr[1000100];
int main()
{
	int i, a, b, cnt, max=0, num, temp;

	scanf("%d %d",&a, &b);

if (a > b)
	{
		temp = a;
		a = b;
		b = temp;
	}

	for (i = a; i <= b; i++)
	{
		temp = i;
		cnt = 0;
		while (1)
		{
			if (arr[temp] != 0)
			{
				cnt += arr[temp];
				arr[i] = cnt;
				if (max < cnt)
					max = cnt;
				break;
			}
			cnt++;
			if (temp % 2 == 0)
			{
				temp /= 2;
			}
			else
			{
				temp *= 3;
				temp++;
			}

			if (temp == 1)
			{
				cnt++;
				arr[i] = cnt;
				if (max < cnt)
					max = cnt;
				break;
			}
		}
	}

	printf("%d\n", max);

	return 0;
}

