#include <iostream>
#include <string>
using namespace std;

int main() {	
	int array[10][10];
	int result = 0;
	int temp = 0;

	// �Է�	
	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 10; j++){
			cin >> array[i][j];
		}
	}	

	// 

	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 6; j++){
			temp = array[i][j] + array[i][j+1] + array[i][j+2] + array[i][j+3] + array[i][j+4];
			if(temp > result) result = temp;
		}
	}

	for(int i = 0; i < 10; i++){
		for(int j = 0; j < 6; j++){
			temp = array[j][i] + array[j+1][i] + array[j+2][i] + array[j+3][i] + array[j+4][i];
			if(temp > result) result = temp;
		}
	}

	cout << result;

	return 0;
}