#include<iostream>
using namespace std;

int main()
{
	int arr[10][10]={0,};
	int temp=0;
	int max=0;

	for(int i=0;i<10;i++)
	{
		for(int j=0;j<10;j++)
		{
			cin >> arr[i][j];
		}
	}

	//����
	for(int a=0;a<10;a++)
	{
		for(int b=0;b<6;b++)
		{
			temp = arr[a][b]+arr[a][b+1]+arr[a][b+2]+arr[a][b+3]+arr[a][b+4];
			if(max<temp)
			{
				max = temp;
			}
		}
	}

	//����
	for(int b=0;b<10;b++)
	{
		for(int a=0;a<6;a++)
		{
			temp = arr[a][b]+arr[a+1][b]+arr[a+2][b]+arr[a+3][b]+arr[a+4][b];
			if(max<temp)
			{
				max = temp;
			}
		}
	}

	cout << max << endl;

	return 0;
}