#include<iostream>

using namespace std;
 
int maze[20][20] = { 0, }; 
int check(int ii, int jj) {
	int big1 = maze[ii][jj];
	int big2 = maze[ii][jj];
	int big3 = maze[ii][jj];
	int big4 = maze[ii][jj];

		for (int j = 1; j < 5; j++) {
			big1+=maze[ii][jj+j];
			big2 += maze[ii][jj - j];
			big3 += maze[ii + j][jj];
			big4 += maze[ii - j][jj];
		}
	
		//cout << big1 << " " << big2 << " " << big3 << " " << big4 << "  (" << ii-5 <<", "<< jj-5 <<")"<<endl;
	if (big1 >= big2 && big1 >= big3 && big1 >= big4)
		return big1;
	else if (big2 >= big1 && big2 >= big3 && big2 >= big4)
		return big2;
	else if (big3 >= big2 && big3 >= big1 && big3 >= big4)
		return big3;
	else
		return big4;
}
int main() {
	 
	for (int i = 5; i < 15; i++) {
		for (int j = 5; j < 15; j++) {
			cin >> maze[i][j];
		}
	} 
	int temp = 0;
	int sum = 0;

	//cout << check(5, 5) << endl;
	for (int i = 5; i < 15; i++) {
		for (int j = 5; j < 15; j++) {
			temp = check(i, j);
			if (temp >= sum)
				sum = temp;
		}
	}
	cout << sum;

	return 0;
}