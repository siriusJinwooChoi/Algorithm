#include <iostream>
#include <algorithm>
using namespace std;
void Search(int i, int k);
int Matrix[20][20] = { 0 };
int maxNum = 0;
int main(){
	for (int i = 0; i <= 11; i++){
		for (int k = 0; k <= 11; k++){
			if (i == 0 || k == 0 || i == 11 || k == 11) Matrix[i][k] = -1;
			else cin >> Matrix[i][k];
		}
	}

	for (int i = 1; i <= 10; i++){
		for (int k = 1; k <= 10; k++){
			Search(i, k);
		}
	}
	cout << maxNum << endl;
	return 0;
}

void Search(int i, int k){
	
	if (Matrix[i - 1][k] != -1 && Matrix[i - 2][k] != -1 && Matrix[i - 3][k] != -1 && Matrix[i - 4][k] != -1){
		maxNum = max(maxNum, Matrix[i][k] + Matrix[i - 1][k] + Matrix[i - 2][k] + Matrix[i - 3][k] + Matrix[i - 4][k]);
	}
	if (Matrix[i + 1][k] != -1 && Matrix[i + 2][k] != -1 && Matrix[i + 3][k] != -1 && Matrix[i + 4][k] != -1){
		maxNum = max(maxNum, Matrix[i][k] + Matrix[i + 1][k] + Matrix[i + 2][k] + Matrix[i + 3][k] + Matrix[i + 4][k]);
	}
	if (Matrix[i][k - 1] != -1 && Matrix[i][k - 2] != -1 && Matrix[i][k - 3] != -1 && Matrix[i][k - 4] != -1){
		maxNum = max(maxNum, Matrix[i][k] + Matrix[i][k - 1] + Matrix[i][k - 2] + Matrix[i][k - 3] + Matrix[i][k - 4]);
	}
	if (Matrix[i][k + 1] != -1 && Matrix[i][k + 2] != -1 && Matrix[i][k + 3] != -1 && Matrix[i][k + 4] != -1){
		maxNum = max(maxNum, Matrix[i][k] + Matrix[i][k + 1] + Matrix[i][k + 2] + Matrix[i][k + 3] + Matrix[i][k + 4]);
	}
	Matrix[i][k] = -1;
}