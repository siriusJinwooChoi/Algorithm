#include <iostream>

using namespace std;

int main()
{
	int arr[10][10]={0};
	int sum1=0,sum2=0;
	int max1=0,max2=0;
	for(int i=0;i<10;i++){
		for(int j=0;j<10;j++){
			cin >> arr[i][j];
		}
	}

	for(int i=0;i<10;i++){
		for(int j=0;j<5;j++){
			sum1 += arr[i][j];
		}

		for(int k=5;k<10;k++){
			sum2 +=arr[i][k];
		}

		if(sum1 > sum2){
			max1 = sum1;
		}else{
			max1 = sum2;
		}

		sum1=0;
		sum2=0;
	}

	for(int i=0;i<10;i++){
		for(int j=0;j<5;j++){
			sum1 += arr[j][i];
		}

		for(int k=5;k<10;k++){
			sum2 +=arr[k][i];
		}

		if(sum1 > sum2){
			max2 = sum1;
		}else{
			max2 = sum2;
		}

		sum1=0;
		sum2=0;
	}

	if(max1 > max2){
		cout << max1 << endl;
	}else{
		cout << max2 << endl;
	}
	return 0;
}