#include <iostream>
using namespace std;
int main()
{
	int num;
	cin >> num;

	cout << '1';
	int sum = 1;
	for (int i = 2; i <= num; ++i) {
		sum += i;
		cout << '+' << i;
	}
	cout << '=' << sum;
}