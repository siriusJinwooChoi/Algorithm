
#include<iostream>
#include<string>

using namespace std;

int main(){
	
	string str;
	
	cin>>str;

	for(int i=0; i<str.length();i++){
		if(str[i]=='h' || str[i]=='H')
			cout<<"Hello, world!"<<endl;
		else if(str[i]=='q'||str[i]=='Q')
			cout<<str<<endl;
		else if(str[i]=='9')
			cout<<"99 Bottles of Beer on the Wall"<<endl;
		else
			break;
			
	}
	
}