#include<iostream>
#include<math.h>
#include<sstream>
#include<string>

using namespace std;

int main(){

	string a;
	cin>>a;

	for(int i=0; i<a.length(); i++){
		if(a[i]=='q'||a[i]=='Q')
			cout<<a<<endl;
		else if(a[i]=='9')
			cout<<"99 Bottles of Beer on the Wall"<<endl;
		else
			cout<<"Hello, world!"<<endl;
	}
}
	

 
    

	
