import java.util.Scanner;


public class Main 
{
	public static String h = "Hello, world!";
	public static String n = "99 Bottles of Beer on the Wall";
	public static String q;
	
	public static void main(String[] args) 
	{
        Scanner scan = new Scanner(System.in);
        q = scan.nextLine();
        
        for(int i=0; i<q.length(); i++)
        {
        	switch(q.charAt(i))
        	{
	        	case 57: System.out.println(n); break;
	        	case 104: case 72: System.out.println(h); break;
	        	case 113: case 81: System.out.println(q); break;
        	}
        }
	}
}
