#include<stdio.h>
#include<string.h>

int main(){

	char h;
	char q;
	int i;
	int len;
	
	char str[27];
	
	scanf("%s",str);
		
	len=strlen(str);
	
	for(i=0; i<len; i++){
		if(str[i]=='H' || str[i]=='h'){printf("Hello, world!\n");}
		else if(str[i]=='Q'|| str[i]=='q'){printf("%s\n",str);}
			else if(str[i]=='9'){printf("99 Bottles of Beer on the Wall\n");}
	}
	
	
	
	
}