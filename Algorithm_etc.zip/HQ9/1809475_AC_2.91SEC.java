import java.util.Scanner;


public class Main{

	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		
		String str = sc.next();
		char s[] = str.toCharArray();
		
		for(int i=0;i<s.length;i++)
		{
			if(s[i] == 'H' || s[i] == 'h')
				System.out.println("Hello, world!");
			else if(s[i] == 'Q' || s[i] == 'q')
				System.out.println(str);
			else if(s[i] == '9')
				System.out.println("99 Bottles of Beer on the Wall");
			else
				System.out.println("�ٽ�");
		}
		
		

	}

}
