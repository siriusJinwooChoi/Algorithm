import java.util.Scanner;

public class Main{
	public static void main(String[] args) {
		
	Scanner s = new Scanner(System.in);
	String input = s.next();
	
	char[] arrIn = input.toCharArray();
	
	for(int i = 0; i < arrIn.length; i++){
		
		switch(arrIn[i])
		{
		case 'q':
			System.out.println(input);
		break;
		
		case 'Q':
			System.out.println(input);
		break;
		
		case 'H':
			System.out.println("Hello, world!");
		break;
		
		case 'h':
			System.out.println("Hello, world!");
		break;
		
		
		case '9':
			System.out.println("99 Bottles of Beer on the Wall");
		break;
		
		}
		
	}
	
	

	}
}
