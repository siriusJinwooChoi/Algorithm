#include<stdio.h>

int main(void){
	char arr[26];
	int i=0,j;

	scanf("%s", &arr);
	while(arr[i] != '\0'){
		if( arr[i] == 'q' || arr[i] == 'Q')
			printf("%s\n", arr);
		else if(arr[i] == '9')
			printf("99 Bottles of Beer on the Wall\n");
		else if(arr[i] == 'h' || arr[i] == 'H')
			printf("Hello, world!\n");
		i++;
	}

	return 0;
}