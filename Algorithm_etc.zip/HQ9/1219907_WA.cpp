#include <iostream>

using namespace std;

int main(){

	char* input;
	int i = 0;

	cin >> input;

	while( input[i] != '\0' ){

		if( input[i] == 'H' || input[i] == 'h' )
			cout << "Hello, world!" << endl;
		else if( input[i] == 'Q' || input[i] == 'q' )
			cout << input << endl;
		else if( input[i] == '9' )
			cout << "99 Bottles of Beer on the Wall" << endl;
		i++;
	}
}