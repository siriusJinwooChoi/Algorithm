#include <stdio.h>
#include <string.h>

int main() {

	char arr[25];
	int i;
	gets(arr);
//	printf("%d",strlen(arr));

	for(i=0 ; i<strlen(arr) ; i++) {
		if((arr[i]=='q')||(arr[i]=='Q')) {
			puts(arr);
		} else if((arr[i]=='h')||(arr[i]=='H')) {
			printf("Hello, world!\n");
		} else if(arr[i]=='9') {
			printf("99 Bottles of Beer on the Wall\n");
		}
	}

}