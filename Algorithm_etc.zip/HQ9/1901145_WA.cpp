#include <stdio.h>

int main(){
	char ch[26] = {};
	int i = 0;
	int n = 0;
	scanf("%s", ch);

	while(ch[n++] != NULL);
	n--;

	for (i = 0; i < n; i++){
		if (ch[i] == 'q' || ch[i] == 'Q'){
			printf("%s", ch);
			printf("\n");
		}
		if (ch[i] == 9)
			printf("99 Bottles of Beer on the Wall\n");
		if (ch[i] == 'h' || ch[i] == 'H')
			printf("Hello, world!\n");
	}



	return 0;

}