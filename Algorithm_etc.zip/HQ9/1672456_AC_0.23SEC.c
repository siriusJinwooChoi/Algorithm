#include <stdio.h>

int main()
{
	char a[30];
	int i = 0;

	scanf("%s", a);

	while ('\0' != a[i]) {
		switch (a[i++]) {
		case 'h':
		case 'H':
			printf("Hello, world!\n");
			break;
		case 'q':
		case 'Q':
			printf("%s\n", a);
			break;
		case '9':
			printf("99 Bottles of Beer on the Wall\n");
			break;
		}
	}

	return 0;
}