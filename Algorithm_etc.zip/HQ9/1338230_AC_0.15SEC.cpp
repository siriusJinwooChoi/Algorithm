#include <stdio.h>
#include "stdlib.h"


int main()
{
	char al[26];
	int i;
	scanf("%s",al);
	
	for(i=0;;i++)
	{
		if(al[i]=='\0')
			break;

		else if(al[i]=='q' || al[i]=='Q')
			printf("%s\n",al);
		else if(al[i]=='h' || al[i]=='H')
			printf("Hello, world!\n");
		else if(al[i]=='9')
			printf("99 Bottles of Beer on the Wall\n");
		//printf("%c",al[i]);
	}

	return 0;
}