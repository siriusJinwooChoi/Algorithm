#include<stdio.h>
#include<string.h>
int main(){
	char input[25];
	int i;
	scanf("%s", input);
	for(i=0; i<strlen(input); i++){
		if(input[i] == 'H' || input[i] == 'h'){
			printf("Hello, world!\n");
		}else if(input[i] == 'Q' || input[i] == 'q'){
			printf("%s\n",input);
		}else if(input[i] == '9'){
			printf("99 Bottles of Beer on the Wall\n");
		}
	}
	return 0;
}