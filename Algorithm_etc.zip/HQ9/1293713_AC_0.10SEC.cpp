#include <iostream>
#include <string>
using namespace std;

string str;
int i;
int main()
{
	cin >> str;

	string H = "Hello, world!";
	string Q = str;
	string K = "99 Bottles of Beer on the Wall";

	for(i=0; i<str.length(); i++)
	{
		switch(str[i])
		{
			case 'h': cout << H << endl; break;
			case 'H': cout << H << endl; break;
			case 'q': cout << Q << endl; break;
			case 'Q': cout << Q << endl; break;
			case '9' : cout << K << endl; break;

		}
	}

}