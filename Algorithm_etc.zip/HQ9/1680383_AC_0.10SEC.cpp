#include<iostream>
#include<string>
using namespace std;

int main(){

	string in;

	cin >> in;

	for (int i = 0; i < in.length(); i++){
		if (in[i] == 'H' || in[i] == 'h'){
			cout << "Hello, world!" << endl;
		}
		else if (in[i] == 'Q' || in[i] == 'q'){
			cout << in << endl;
		}
		else if (in[i] == '9'){
			cout << "99 Bottles of Beer on the Wall" << endl;
		}
	}
}