#include <stdio.h>

int main(){
	int i;
	char input[26];

	scanf("%s", input);

	for (i = 0; i < 26; i++){
		if (input[i] == 'h' || input[i] == 'H')
			printf("Hello, world!\n");
		else if (input[i] == 'q' || input[i] == 'Q')
			printf("%s\n", input);
		else if (input[i] == '9')
			printf("99 Bottles of Beer on the Wall\n");
		else
			break;
	}
}