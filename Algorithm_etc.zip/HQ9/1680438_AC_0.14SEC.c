#include <stdio.h>
char a[100] = {'H','e','l','l','o',',',' ','w','o','r','l','d','!'};
char b[100] = {'9','9',' ','B','o','t','t','l','e','s',' ','o','f',' ','B','e','e','r',' ','o','n',' ','t','h','e',' ','W','a','l','l'};

int main()
{
    char input[1000];
    int i=0;
    scanf("%s",input);
    for(i=0;input[i]!='\0';i++)
    {
        if(input[i]=='Q'||input[i]=='q')
        {
            printf("%s\n",input);
            
        }
        if(input[i] =='H'||input[i] == 'h')
        {
            printf("%s\n",a);
        }
        if(input[i]=='9')
        {
            printf("%s\n",b);
        }
        
    }
}