#include <iostream>
#include <string>

using namespace std;

string input;
string h = "Hello, world!";
string q;
string nine = "99 Bottles of Beer on the Wall";

int main(){

	cin >> input;

	q = input;

	for( int i = 0; i < input.length(); i++ ){
		switch(input[i]){
		case 'h':
			cout << h << endl;
			break;
		case 'H':
			cout << h << endl;
			break;
		case 'q':
			cout << q << endl;
			break;
		case 'Q':
			cout << q << endl;
			break;
		case '9':
			cout << nine << endl;
			break;
		}
	}
}