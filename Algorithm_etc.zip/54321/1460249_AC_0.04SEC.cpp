#include <iostream>

using namespace std;

int main()
{
	int n;
	
	cin >> n;

	for(int i=n;i>0;i--){
		cout << i;
		for(int j=i-1;j>0;j--){
			cout << j;
		}
		cout << endl;
	}
}