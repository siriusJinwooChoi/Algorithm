#include <iostream>
using namespace std;

int main()
{
	int n, temp; cin >> n;
	temp = n;
	for(int i=0 ; i<n ; i++, temp--)
	{
		for(int a=temp ; a>0 ; a--)
			cout << a;
		cout << endl;
	}
}