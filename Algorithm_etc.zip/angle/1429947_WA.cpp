#include <iostream>

using namespace std;

int main()
{
	int n;
	int inner,outer;

	cin >> n;

	if(n==3){
		inner = 180;
	}else{
		inner = n/2*180;
	}
	cout << inner <<" "<<360<<endl;
	return 0;
}