#include <stdio.h>

int main(){
	int a;
	int inner, outer;

	scanf("%d", &a);

	inner = (a - 2) * 180;
	outer = (180 - (inner / a)) * a;

	printf("%d %d", inner, outer);
}