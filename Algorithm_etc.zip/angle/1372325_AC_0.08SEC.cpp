#include <stdio.h>

int main(){
	int a;
	int inner, outer;

	scanf("%d", &a);

	inner = (a - 2) * 180;
	outer = a * 180 - inner;

	printf("%d %d", inner, outer);
}