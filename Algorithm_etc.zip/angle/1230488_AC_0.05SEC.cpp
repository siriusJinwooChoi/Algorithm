#include <iostream>

using namespace std;

int main(){

	int n;

	cin >> n;

	cout << 180*(n-2) << " " << "360" << endl;
}