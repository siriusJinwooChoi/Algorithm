#include <stdio.h>

int main()
{
	 int x;
	 int minx;
	 int in,out;

	 scanf("%d", &x);

	 minx = x - 2;
	 in = minx * 180;
	 out = x*180 - in;

	 printf("%d %d", in, out);
}