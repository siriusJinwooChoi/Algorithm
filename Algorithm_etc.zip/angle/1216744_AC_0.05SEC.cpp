#include <iostream>

using namespace std;

int main()
{
	int a, b, c, d;

	cin >> a;

	cout << (a-2)*180 << " 360" << endl;

}