#include<stdio.h>
void main(){
	int n;
	int in;
	in = 180;
	scanf("%d", &n);
	while( n > 3 ){
		in += 180;
		n--;
	}
	printf("%d 360\n", in);
}
