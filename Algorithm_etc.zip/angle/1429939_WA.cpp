#include <iostream>

using namespace std;

int main()
{
	int n;
	int inner, outer;

	cin >> n;
	inner = n*60;
	outer = (180-60)*n;

	cout << inner <<" "<<outer<<endl;
	return 0;
}