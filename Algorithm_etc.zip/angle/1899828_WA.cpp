
#include <stdio.h>

int main(){
	int n;
	scanf("%d", &n);
	
	printf("%d %d", 360/(n-1), 360-(360/(n-1)));
	
	return 0;
}