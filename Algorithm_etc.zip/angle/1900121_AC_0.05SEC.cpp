#include <iostream>
int main()
{
int n;
std::cin>>n;
std::cout<<180*(n-2)<<' '<<360;}