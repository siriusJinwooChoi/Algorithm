#include <stdio.h>
int main(){
	int n;
	int result1, result2;

	scanf("%d", &n);

	result1= 180*(n-2);
	result2 = 360;

	printf("%d %d\n", result1, result2);

	return 0;
}