#include <stdio.h>
int main(void)
{
		
	int n;
	int sum_in=0, sum_out=0;

	scanf("%d", &n);

	sum_in= 180*(n-2);
	sum_out= 360;
	
	printf("%d %d", sum_in, sum_out);
	return 0;
}
