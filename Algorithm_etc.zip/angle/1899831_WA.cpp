#include <stdio.h>

int main(){
	int n;
	scanf("%d", &n);
	
	printf("%d %d", (180/n)*n, (180-180/n)*n);
	
	return 0;
}