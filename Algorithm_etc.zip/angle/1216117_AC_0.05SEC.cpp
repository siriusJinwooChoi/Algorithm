#include<iostream>

using namespace std;

int main(){

	int a1,a2;
	cin>>a1;
	
	int result;
	result = (a1-2)*180;
	cout<<result<<" "<<360<<endl;
}