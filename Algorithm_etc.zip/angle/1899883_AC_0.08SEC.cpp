#include <stdio.h>

int main(){
	int n;
	scanf("%d", &n);
	
	double in, out;
	in=180*((double)n-2);
	out=(((double)180-((double)in/(double)n))*(double)n);
	printf("%.0lf %.0lf", in, out);
	
	return 0;
}