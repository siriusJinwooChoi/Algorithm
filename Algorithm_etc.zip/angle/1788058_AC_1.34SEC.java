import java.util.Scanner;


public class Main {

	public static void main(String[] args) {
		// TODO Auto-generated method stub
		Scanner sc = new Scanner(System.in);
		
		int n;
		int inAngle, outAngle;
		
		n = sc.nextInt();
		
		inAngle = (n-2)*180;
		outAngle = (n*180)-((n-2)*180);
		
		System.out.println(inAngle + " " + outAngle);
		
	}

}
