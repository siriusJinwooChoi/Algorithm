#include <iostream>
using namespace std;

int card[7];

int main() {
	int temp;
	int gin=0;
	
	for (int i = 1; i <= 6; i++) {
		cin >> card[i];
	}

	for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 6; j++) {
			if (card[i] < card[j]) {
				temp = card[j];
				card[j] = card[i];
				card[i] = temp;
			}
		}
	}

	for (int i = 1; i <= 6; i++) {
		int count = 0;
		for (int j = 1; j <= 6; j++) {
			if (card[i] == card[j]) count++;
		}
		if (count == 6) {
			gin += 2; break;
		}
		else if (count >= 3) {
			gin += 1;
		}
		else {
			count = 0;
			int r=card[i];
			for (int j = 1; j <= 6; j++) {
				if (r == card[j]) {
					count++;
					r++;
				}
			}
			if (count == 6) {
				gin += 2; break;
			}
			else if (count >= 3) {
				gin += 1;
			}
		}
	}
	if (gin == 2)  cout << "gin" << endl;
	else cout << "lose" << endl;

	return 0;
}