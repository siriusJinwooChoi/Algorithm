#include <iostream>
#include <algorithm>

using namespace std;

int arr[10]={0};
int arr2[4]={0};
int cnt=0;
int num=0;
int ck_num=0;
int check_tripletes() // ���� ����
{
	
	int num2=0;
	int indx=0;
	int cnt2=0;
	for(int i=0;i<6;i++){
		for(int j=i+1;j<6;j++){
			if(arr[i] != ck_num && arr[i] == arr[j]){
				cnt2++;
			}
			if(cnt2==2){
				return 1;
				break;
			}
		}
		cnt2=0;
	}
	
}
int check_run() // ���ӵ� ����
{
	for(int i=0;i<6;i++){
		if(ck_num != arr[i]){
			
			if(arr[i+1] - arr[i] == 1  && arr[i+2] - arr[i+1] == 1){
				return 1;
				break;
			}
		}
	}
}
int check_run2()
{
	int cnt3=0;
	for(int i=0;i<6;i++){
		if(arr[i+1] - arr[i] == 1){
			cnt3++;
		}
		if(cnt3 == 5){
			return 1;
			break;
		}
	}
}
int main()
{
	
	for(int i=0;i<6;i++){
		cin >> arr[i];
	}

	sort(arr,arr+6);
	
	for(int i=0;i<6;i++){
		num  = arr[i];
		if(num == arr[i]){
			arr2[cnt] = i;
			cnt++;
			if(cnt == 3){
				ck_num = num;
				break;
			}
		}
		cnt=0;
	}


	if(cnt == 3){
		if(check_tripletes() == 1){
			cout << "gin" << endl;
		}else if(check_run() == 1){
			cout << "gin" << endl;
		}else{
			cout << "lose" << endl;
		}
	}else{
		if(check_run2() == 1){
			cout << "gin" << endl;
		}else{
			cout << "lose" << endl;
		}
	}

}