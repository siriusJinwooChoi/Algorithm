#include<iostream>
#include<algorithm>
using namespace std;

int main(){
	int arr[6] = { 0 };
	for (int i = 0; i < 6; i++){
		cin >> arr[i];
	}
	sort(arr, arr + 6);
	int cnt = 0;
	for (int i = 0; i < 6; i++){
		if (arr[i] == arr[i + 1]){
			if (arr[i] == arr[i + 2]) {
				cnt++;
				arr[i] = -1;
				arr[i + 1] = -1;
				arr[i + 2] = -1;
			}
		}
		if (arr[i] == arr[i + 1] && arr[i + 2] == arr[i + 3] && arr[i + 4] == arr[i + 5])
		{
			int c = arr[5] - arr[3];
			int d = arr[3] - arr[1];
			if (c == 1 && d == 1) cnt = 2;
		}
		
	}
	sort(arr, arr + 6);
	int i = 5;
	if (arr[i] == arr[i - 1] && arr[i] == arr[i - 2]) cnt++;
	else {
		if (arr[i]>arr[i - 1]){
			int a = arr[i] - arr[i - 1];
			int b = arr[i - 1] - arr[i - 2];
			if (a == 1 && b == 1) cnt++;
		}
		else{
			int a = arr[i-1] - arr[i];
			int b = arr[i - 2] - arr[i - 1];
			if (a == 1 && b == 1) cnt++;
		}
	}
	if (cnt == 2) cout << "gin" << endl;
	else cout << "lose" << endl;
}