#include <iostream>
using namespace std;

int card[7];

int main() {
	int temp;
	int gin=0;
	
	for (int i = 1; i <= 6; i++) {
		cin >> card[i];
	}

	for (int i = 1; i <= 6; i++) {
		for (int j = 1; j <= 6; j++) {
			if (card[i] < card[j]) {
				temp = card[j];
				card[j] = card[i];
				card[i] = temp;
			}
		}
	}

	for (int i = 1; i <= 4; i=i+3) {
		if ((card[1] + 1 == card[3] && card[1] + 2 == card[5]) && (card[2] + 1 == card[4] && card[2] + 2 == card[6])) {
			gin = gin + 2; break;
		}
		if (card[i + 2] == card[i] && card[i+1]== card[i]) {
			gin++;
		}
		if (card[i] + 1 == card[i + 1] && card[i + 1] + 1 == card[i + 2])
			gin++;
	}
	if (gin == 2)  cout << "gin" << endl;
	else cout << "lose" << endl;

	return 0;
}