#include <stdio.h>
int arr[10] = { 0 };

int main(){
	int input, flag, cnt_three, cnt_six;
	int i, j;

	cnt_three = cnt_six = flag = 0;
	for (i = 0; i < 6; i++){
		scanf("%d", &input);
		arr[input]++;
		if (arr[input] == 3){
			cnt_three++;
			arr[input] = 0;
			flag = 2;
			if (cnt_three == 2)
				flag = 1;
		}
		else if (arr[input] == 6){
			cnt_six++;
			flag = 1;
		}
	}
	if (flag == 2){
		for (i = 0; arr[i] == 0; i++);
		if (arr[i] == 1 && arr[i + 1] == 1 && arr[i + 2] == 1)
			flag = 1;		
	}
	/*else if (flag != 1){
		for (i = 0; arr[i] == 0; i++);
		if (arr[i] >= 1 && arr[i + 1] >= 1 && arr[i + 2] >= 1){
			arr[i]--;
			arr[i + 1]--;
			arr[i + 2]--;
			flag = 2;
		}
		if (flag == 2){
			for (i = 9; arr[i] == 0; i--);
			if (arr[i] == 1 && arr[i - 1] == 1 && arr[i - 2] == 1)
				flag = 1;
		}
			
	}*/

	if (flag == 1)
		printf("gin\n");
	else
		printf("lose\n");

	return 0;
}