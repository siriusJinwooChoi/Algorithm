#include <iostream>
#include <algorithm>
using namespace std;
int arr[10] = { 0, };
int tripleIndex[10] = { 0, };
int seq[10] = { 0, };
int cnt=0;
void printArr(){
	for (int i = 1; i <= 6; i++){
		cout << arr[i] << " ";
	}
}
void process1(){
	if (arr[1] == arr[2] && arr[2] == arr[3]){
		cnt++;
	}
	if (arr[4] == arr[5] && arr[5] == arr[6]){
		cnt++;
	}
	if (arr[2] == arr[1] + 1 && arr[3] == arr[2] + 1){
		cnt++;
	}
	if (arr[5] == arr[4] + 1 && arr[6] == arr[5] + 1){
		cnt++;
	}
}
int main(){

	for (int i = 1; i <= 6; i++){
		cin >> arr[i];
	}
	sort(arr + 1, arr + 7);
	//printArr();

	process1();

	if (cnt == 2) cout << "gin" << endl;
	else cout << "lose" << endl;
	//��
	return 0;
}