#include <iostream>
#include <algorithm>
#include <stack>
using namespace std;

int mycard[10];
int check[10];
int gin_point = 0;

void check_run(){
	for (int i = 0; i < 8; i++){
		if (mycard[i] > 0 && mycard[i + 1] > 0 && mycard[i + 2] > 0){
			int minimum_count = 9999;
			for (int j = i; j <= i + 2;j++){
				if (mycard[j] < minimum_count)
					minimum_count = mycard[j];
			}
			mycard[i] -= minimum_count; mycard[i + 1] -= minimum_count; mycard[i + 2] -= minimum_count;
		}
	}
}
void check_triplate(){
	for (int i = 0; i < 10; i++){
		if (mycard[i] / 3 != 0){
			mycard[i] %= 3;
		}
	}
}
int main(){
	for (int i = 0; i < 6; i++){
		int cardnumber;
		cin >> cardnumber;
		mycard[cardnumber]++;
	}
	/*for (int i = 0; i < 10; i++){
		cout << mycard[i] << " ";
	}
	cout << endl;*/
	check_triplate(); check_run();
	/*for (int i = 0; i < 10; i++){
		cout << mycard[i] << " ";
	}
	cout << endl;*/
	for (int i = 0; i < 10; i++){
		if (mycard[i] != 0){
			cout << "lose" << endl;
			return 0;
		}
	}
	cout << "gin" << endl;
	return 0;
}