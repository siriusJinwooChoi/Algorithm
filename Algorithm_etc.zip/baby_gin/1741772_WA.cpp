#include <iostream>
#include <algorithm>
#include <stack>
using namespace std;

int mycard[10];
int check[10];
int gin_point = 0;

void check_run(){
	int target[10];
	for (int i = 0; i < 10; i++){
		target[i] = mycard[i];
	}
	for (int i = 0; i < 8; i++){
		if (target[i] > 0 && target[i + 1] > 0 && target[i + 2] > 0){
			int minimum_count = 9999;
			for (int j = i; j <= i + 2;j++){
				if (target[j] < minimum_count)
					minimum_count = target[j];
			}
			gin_point += minimum_count;
			check[i] += minimum_count; check[i + 1] += minimum_count; check[i + 2] += minimum_count;
		}
	}
}
void check_triplate(){
	for (int i = 0; i < 10; i++){
		gin_point += (mycard[i] / 3);
		if (mycard[i] / 3 != 0){
			check[i] += (mycard[i] / 3) * 3;
		}
	}
}
int main(){
	for (int i = 0; i < 6; i++){
		int cardnumber;
		cin >> cardnumber;
		mycard[cardnumber]++;
	}
	check_run(); check_triplate();
	// cout << gin_point << endl;
	/*for (int i = 0; i < 10; i++){
		cout << mycard[i] << " ";
	}
	cout << endl;
	for (int i = 0; i < 10; i++){
		cout << check[i] << " ";
	}
	cout << endl;*/
	for (int i = 0; i < 10; i++){
		if (mycard[i] != check[i]){
			cout << "lose" << endl;
			return 0;
		}
	}
	cout << "gin" << endl;
	return 0;
}