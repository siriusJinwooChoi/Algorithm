#include <iostream>

using namespace std;

int main(){
	int arr[6] = { 0, };

	for (int i = 0; i < 6; i++)
		cin >> arr[i];

	for (int i = 5; i >= 0; i--){
		for (int j = 0; j < i; j++){
			if (arr[j] > arr[j + 1]){
				int temp = arr[j];
				arr[j] = arr[j + 1];
				arr[j + 1] = temp;
			}
		}
	}

	int flag = 0;

	if (arr[0] + 1 == arr[1] && arr[1] + 1 == arr[2]){
		if (arr[3] == arr[4] == arr[5])
			flag = 1;
		else if (arr[2] == arr[3] == arr[4] == arr[5])
			flag = 1;
	}
	else if (arr[3] + 1 == arr[4] && arr[4] + 1 == arr[5]){
		if (arr[0] == arr[1] == arr[2] == arr[3])
			flag = 1;
		else if (arr[0] == arr[1] == arr[2])
			flag = 1;
	}
	else{
		if (arr[0] == arr[1] == arr[2] && arr[3] == arr[4] == arr[5])
			flag = 1;
		else if (arr[0] == arr[1] == arr[2] == arr[3] == arr[4] == arr[5])
			flag = 1;
		else if (arr[0] == arr[1] && arr[2] == arr[3] && arr[4] == arr[5]){
			if (arr[1] < arr[2])
				flag = 1;
		}
		
	}

	if (flag == 1)
		cout << "gin" << endl;
	else
		cout << "lose" << endl;
}