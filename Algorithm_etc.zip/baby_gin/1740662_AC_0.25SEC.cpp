#include <iostream>
#include <algorithm>

using namespace std;

int num[10];
int main(){

	int tripple1 = 0;
	int tripple2 = 0;
	int runs1 = 0;
	int runs2 = 0;
	for (int i = 0; i < 6; i++)
	{
		cin >> num[i];
	}
	
	sort(num, num + 6);

	if ((num[0]==num[1]&&num[2]==num[3]&&num[4]==num[5])&&(num[2]-num[0]==1&&num[4]-num[2]==1)){
		runs1 = 1;
		runs2 = 1;
	}
	else if (num[1]-num[0]==1&&num[1]==num[2]&&num[2]==num[3]&&num[3]==num[4]){
		if (num[5] - num[1] == 1){
			runs1 = 1;
			tripple2 = 1;
		}
	}
	else
	{
		if (num[0] == num[1] && num[1] == num[2])
		{
			tripple1 = 1;
		}
		else if ((num[1] - num[0] == 1) && (num[2] - num[1] == 1))
		{
			runs1 = 1;
		}
		else{
			tripple1 = 0;
			runs1 = 0;
		}


		if (num[3] == num[4] && num[4] == num[5])
		{
			tripple2 = 1;
		}
		else if ((num[4] - num[3] == 1) && (num[5] - num[4] == 1))
		{
			runs2 = 1;
		}
		else{
			tripple2 = 0;
			runs2 = 0;
		}
	}


	if (tripple1&&tripple2)
	{
		cout << "gin" << endl;
	}
	else if (tripple1&&runs2){
		cout << "gin" << endl;
	}
	else if (runs1&&tripple2){
		cout << "gin" << endl;
	}
	else if (runs1&&runs2){
		cout << "gin" << endl;
	}
	else{
		cout<<"lose" << endl;
	}
	
	return 0;
}