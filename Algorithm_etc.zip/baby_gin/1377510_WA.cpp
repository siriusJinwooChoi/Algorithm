#include <stdio.h>
int main(){
	int arr[6];
	int run, tri;

	for(int i=0; i<6; i++){
		scanf("%d", &arr[i]);
	}

	tri =0; 
	run=0;
	for(int i=0; i<6; i++){

		if(arr[i]==arr[i+1]-1&& arr[i]==arr[i+2]-2) run++;
		if(arr[i]==9)run=0;
	}
	for(int i=0; i<6; i++){
		for(int j=i+1; j<6; j++){
			if(arr[i]==arr[j]) tri++;
		}
	}

	if(tri>=2 || run>=1) printf("gin");
	else printf("lose");

	return 0;
}