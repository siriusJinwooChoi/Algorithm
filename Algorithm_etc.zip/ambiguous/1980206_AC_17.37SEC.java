import java.util.Scanner;

public class Main {
     
    public static void main(String arg[]){
    	Scanner input = new Scanner(System.in);
    	int n = input.nextInt();
    	int arr[] = new int[n+1];
    	int newArr[] = new int[n+1];
    	for(int i=1 ; i<=n ; i++) {
    		arr[i] = input.nextInt();
    		newArr[arr[i]] = i;
    	}
    	boolean isAmbiguous = true;
    	for(int i=1 ; i<=n ; i++) {
    		if(arr[i] != newArr[i]) {
    			isAmbiguous = false;
    			break;
    		}
    	}
    	
    	if(isAmbiguous) {
    		System.out.println("ambiguous");
    	} else {
    		System.out.println("not ambiguous");
    	}
    }
}