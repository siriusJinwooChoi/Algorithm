import java.util.Scanner;

public class Main {

	public static void main(String arg[]){
		Scanner sc = new Scanner(System.in);
		int N = sc.nextInt();
		int friendly[] = new int[N+1];
		for(int i=1 ; i<=N ; i++) {
			friendly[i] = sc.nextInt();
		}

		int tree[] = new int[N+1];
		while(true) {
			int child = sc.nextInt();
			int parent = sc.nextInt();
			if(child == 0 && parent == 0) {
				break;
			}
			tree[child] = parent;
		}

		int root = 0;
		for(int i=1 ; i<=N ; i++) {
			int tmp = i;
			while(true){
				if(tree[tmp] == 0)  {
					root = tmp;
					break;
				}
				tmp = tree[tmp];
			}
			if(root != 0) {
				break;
			}
		}

		int employeeTree[][] = new int[N+1][N+1];
		int prnt = employeeTree[1][1] = root;
		int depth = 1;
		int colCount = 1;
		
		
		while(true) {
			boolean terminalNode = true;
			int cnt = 0;
			for(int c=1 ; c<=colCount ; c++) {
				prnt = employeeTree[depth][c];
				for(int i=1 ; i<=N ; i++) {
					if(tree[i] == prnt) {
						employeeTree[depth+1][++cnt] = i;
						terminalNode = false;
					}
				}
			}
			colCount = cnt;
			
			if(terminalNode) {
				break;
			}
			depth++;
		}
		
		int max = 0;
		int start = 1;
		while(start <= 2) {
			int sum = 0;
			for(int i=start ; i<=depth ; i+=2) {
				for(int j=1 ; j<=N ; j++) {
					if(employeeTree[i][j] == 0) {
						break;
					}
					sum += friendly[employeeTree[i][j]];
				}
			}
			max = Math.max(max, sum);
			start++;
		}
		
		System.out.println(max);
		
	}
}