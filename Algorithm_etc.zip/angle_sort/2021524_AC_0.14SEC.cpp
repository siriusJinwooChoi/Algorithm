#include <stdio.h>
#include <math.h>
#include <algorithm>

using namespace std;

#define PI 3.141592

typedef struct Angle{
	int No;
	double d;
}Angle;

Angle A[101];
int N;

bool Op(Angle a, Angle b) {
	return a.d <b.d;
}

double Get_Degree(double x, double y) {
	double degree, radian;
	radian = atan(y/x);
	degree = radian * 180 / PI;
	if(x<0) degree += 180;
	if(degree<0) degree+=360;
	return degree;
}

void Input() {
	int i;
	double x,y, degree;
	scanf("%d", &N);
	for(i=0; i<N; i++) {
		scanf("%lf %lf",&x, &y);
		A[i].d = Get_Degree(x,y);
		A[i].No = i+1;
	}
}

int main () {
	int i;
	Input();
	sort(A,A+N,Op);
	for(i=0; i<N; i++) printf("%d ",A[i].No);
	return 0;
}