#include<stdio.h>
int main(){
	char start='A';
	char end='Z';
	char i,j,k;
	for(i = start; i<=end; i++){
		for(j = start; j<=end; j++){
			for(k = start; k<=end; k++){
				printf("%c%c%c ",i,j,k);
			}
		}
	}
	return 0;
}