#include <iostream>
#include <string.h>
using namespace std;
int main()
{
	char arr[]={'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};
	int len = strlen(arr);
	cout<<len<<endl;
	for(int i=0; i<26; i++)
		for(int j=0; j<26; j++)
			for(int k=0; k<26; k++)
				cout<<arr[i]<<arr[j]<<arr[k]<<" ";
	cout<<endl;
	return 0;
}