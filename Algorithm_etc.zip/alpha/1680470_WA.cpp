#include <iostream>
#include <string.h>
using namespace std;

int main() {
	char t1 = 'A';
	char t2 = 'A';
	char t3 = 'A';
	// your code goes here
	for(int i=0; i<17576; i++) {
		if(t3 == 'Z') {
			t3 = 'A';
			t2++;
		}
		if(t2 == 'Z') {
			t2 == 'A';
			t1++;
		}
		if(t1 == 'Z' && t2 == 'Z' && t3 =='Z') {
			break;
		}
		cout << t1 << t2 << t3 << " ";
		t3++;
	}
	
	return 0;
}