#include <iostream>
using namespace std;

int visit[30];

void str(char* arr, int count, int total_count){
	if(count==total_count){
		for(int i=0; i<3; i++){
			cout<<arr[i];
		}
		cout<<endl;
		return;
	}
	else{
		for(int i=0; i<26; i++){
			arr[count]='A'+i;
			str(arr,count+1,3);
		}
	}

}

int main(){
	char arr[10];
	str(arr,0,3);
}