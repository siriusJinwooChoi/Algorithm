#include <stdio.h>

int main(){
	int a = 0x41, i, j, k;

	for (i = 0; i < 26; i++)
		for (j = 0; j < 26; j++)
			for (k = 0; k < 26; k++)
				printf("%c%c%c ", a + i, a + j, a + k);	
}