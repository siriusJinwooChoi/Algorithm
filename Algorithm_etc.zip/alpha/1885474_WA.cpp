#include <stdio.h>
#define SWAP(a,b){int tmp=a;a=b;b=tmp;}
void re(char ch1[30],int s,int n){
	int i;
	char ch[30];

	for (i = 0; i < n; i++){
		ch[i] = ch1[i];
	}


	if (s == 3){
		printf("%c%c%c ", ch[0], ch[1], ch[2]);
		return;
	}

	for (i = s; i < n; i++){
		SWAP(ch[i],ch[s]);
		re(ch,s + 1, n);
	}
}

int main() {
	int i = 0;
	int n;
	char ch[30];


	n = 'Z' - 'A' + 1;
	for (i = 0; i < n; i++){
		ch[i] = i + 'A';
	}

	re(ch,0, n);

}