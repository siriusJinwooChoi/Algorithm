#include <stdio.h>
#include <string.h>
int main(){
	int i, j, k;
	char A, B, C;
	A = B = C = 65;
	for (i = 65; i <= 'Z'; i++){
		for (j = 65; j <= 'Z'; j++){
			for (k = 65; k <= 'Z'; k++){
				A = i;
				B = j; 
				C = k;
				printf("%c%c%c ", A, B, C);
			}
		}
	}
}