#include<stdio.h>
#include<string.h>
int main(){
	char start='A';
	char end='Z';
	char i,j,k;
	for(i = start; i<=end; i++){
		for(j = start; j<=end; j++){
			for(k = start; k<=end; k++){
				printf("%d%d%d ",i,j,k);
			}
		}
	}
	return 0;
}