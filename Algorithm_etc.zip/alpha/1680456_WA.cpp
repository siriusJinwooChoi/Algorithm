#include <iostream>
using namespace std;
int main(){
    char a,b,c;
    for (int i = 0; i < 26; i++){
        for (int j = 0; j < 26; j++){
            for (int k = 0; k < 26; k++){
                a = 'a' + i;
                b = 'a' + j; 
                c = 'a' + k;
	cout << a << b << c << " ";  
          }
        }
    }
return 0;
}