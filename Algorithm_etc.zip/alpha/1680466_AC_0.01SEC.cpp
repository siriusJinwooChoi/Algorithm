#include <iostream>
using namespace std;
int main(){
	char alpha = 'A';
	int alpha2index = alpha;
	// A /  b c d e f / g h i j k / l m n o p / q r s t u / v w x y z
	for (int i = 0; i < 26; i++){
		for (int j = 0; j < 26; j++){
			for (int k = 0; k < 26; k++){
				char first = alpha + i;
				char second = alpha + j;
				char third = alpha + k;
				cout << first << second << third << " ";
			}
		}
	}
	return 0;
}