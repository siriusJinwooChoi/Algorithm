#include <stdio.h>
#include <string.h>
int main(){
	int i, j, k;
	for (i = 65; i <= 'Z'; i++)
		for (j = 65; j <= 'Z'; j++)
			for (k = 65; k <= 'Z'; k++)
				printf("%c%c%c ", i, j, k);
}