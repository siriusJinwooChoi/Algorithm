#include <stdio.h>

int main()
{
    char a=0,b=0,c=0;


    for(a=65;a<=90;a++)
    {
        for(b=65;b<=90;b++)
        {
            for(c=65;c<=90;c++)
            {
                printf("%c%c%c ",a,b,c);
            }
                
        }
        
    
    }
}
