#include<iostream>
#include<string.h>
using namespace std;

int main(){
	char arr[26] = {'A','B','C','D','E','F','G','H','I','J','K','L','M','N','O','P','Q','R','S','T','U','V','W','X','Y','Z'};

	for(int i=0; i<26; i++){
		for(int j=0;j<26;j++){
			for(int z=0;z<26;z++){
				cout << arr[i]<< arr[j]<< arr[z]<< " ";
			}
		}
	}
	return 0;
}