#include<stdio.h>

int main(){
	char a[26];
	char b[26];
	char c[26];
	
	int i,j,k;
	int d='A';
	int e='A';
	int f='A';
	
	for(i=0;i<26; i++){
		a[i] = d;
		d++;
	}
	
	for(j=0;j<26; j++){
		
		b[j] = e;
		e++;
	}
	
	for(k=0;k<26; k++){
		
		c[k] = f;
		f++;
	}    // A~Z 3���� �迭�� ������ �Է�
	
	
	for(i=0; i<26; i++){
		for(j=0; j<26; j++){
			for(k=0; k<26; k++){
				printf("%c%c%c ",a[i],b[j],c[k]);
			}
		}
	}
	
	return 0;
}