#include<iostream>
#include<stdio.h>
#include<string.h>
using namespace std;
int main(){
	char start='A';
	char end='Z';

	for(char i = start; i<=end; i++){
		for(char j = start; j<=end; j++){
			for(char k = start; k<=end; k++){
				cout<<i<<j<<k<<" ";
			}
		}
	}
	return 0;
}