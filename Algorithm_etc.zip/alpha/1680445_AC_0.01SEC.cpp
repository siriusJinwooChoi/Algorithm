#include <iostream>
#include <string.h>
using namespace std;

int main()
{
	char *alpha = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";
	char str[4] = { 0, };
	for (int i = 0; i < strlen(alpha); i++) {
		str[0] = alpha[i];
		for (int j = 0; j < strlen(alpha); j++) {
			str[1] = alpha[j];
			for (int k = 0; k < strlen(alpha); k++) {
				str[2] = alpha[k];
				cout << str << " ";
			}
		}
	}
	return 0;
}