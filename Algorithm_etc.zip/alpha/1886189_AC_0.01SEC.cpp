/*
 
 VCPP, GPP���� ���
 
 */

#include <iostream>
using namespace std;

void recursivePrint(int idx, int endIdx, char array[4]){
    if(idx>=endIdx){
        printf("%c%c%c ",array[0],array[1],array[2]);
    }else{
        for(int i = 'A' ; i <= 'Z' ; i++){
            array[idx] = (char)i;
            recursivePrint(idx+1, endIdx, array);
        }
    }
}

int main()
{
    char a[4];
    a[0] = '\0';
    a[1] = '\0';
    a[2] = '\0';
    a[3] = '\0';
    recursivePrint(0,3,a);
    return 0;	/* �ݵ�� return 0���� ���ּž��մϴ�. */ 
    
}