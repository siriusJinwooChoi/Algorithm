import java.util.Scanner;


public class Main
{
	public static void main(String[] args) 
	{
        Scanner scan = new Scanner(System.in);
        String arChar[] = {"A","B","C","D","E","F","G","H","I","J","K","L","M","N","O","P","Q","R","S","T","U","V","W","X","Y","Z"};
        
        for(int i=0; i<arChar.length; i++)
        {
        	for(int j=0; j<arChar.length; j++)
            {
        		for(int k=0; k<arChar.length; k++)
                {
        			System.out.print(arChar[i]+arChar[j]+arChar[k]+" ");
                }
            }
        }
	}
}
