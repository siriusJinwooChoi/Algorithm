#pragma warning(disable : 4996)
#include <stdio.h>
#include <iostream>
#include<string.h>
using namespace std;

int main(){
	int a, b, c;
	int i, j, k;

	for (i = 'A'; i <= 'Z'; i++){
		for (j = 'A'; j <= 'Z'; j++){
			for (k = 'A'; k <= 'Z'; k++){
				cout << (char)i << (char)j << (char)k << ' ';
			}
		}
	}
}