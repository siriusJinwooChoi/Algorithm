#include <stdio.h>

int main()
{
  int i,j,k;

  for (i=65; i<=90; i++)
  for (j=65; j<=90; j++)
  for (k=65; k<=90; k++)
    printf("%c%c%c ", i, j, k);
}
