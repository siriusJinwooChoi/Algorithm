public class Main{
	public static void main(String[] args) {
		
		
		//System.out.println("aaaaa");
		
		for(int i = 65; i < 91; i++){
			System.out.println(" ");
			for(int j = 65; j < 91; j++){

				for(int k = 65; k < 91; k++){
					System.out.print((char)i+"");
					System.out.print((char)j+"");
					System.out.print((char)k+" ");
				}
			}
		}
		
	}

}