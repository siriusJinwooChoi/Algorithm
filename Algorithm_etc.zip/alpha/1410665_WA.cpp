#include<iostream>
#include<math.h>
#include<sstream>

using namespace std;

int main(){
		
	char a,b,c;
	a='A';
	b='A';
	c='A';

	while(a!='Z'){

		while(b!='Z'){
			while(c!='Z'){
				cout<<a<<b<<c<<" ";
				c++;
			}
			b++;
		}
		a++;
	}
	cout<<a<<b<<c;
}

	

 
    

	
