#include <iostream>

using namespace std;

char one = 'A';
char two = 'A';
char three = 'A';

int main()
{
	char four = 'Z';

	cout << (int)one << endl;  // 65
	cout << (int)four << endl; // 90

	for( int i = 0; i <= 25; i++ )
	{
		for( int j = 0; j <= 25; j++ )
		{
			for( int k = 0; k <= 25; k++ )
			{
				cout<< (char)(one+i) << (char)(two+j) << (char)(three+k) <<" ";
			}
		}
	}
}