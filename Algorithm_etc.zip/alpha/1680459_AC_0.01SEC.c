#include<stdio.h>
#include<string.h>

int main(){


	char a = 'A';
	char b = 'A';
	char c = 'A';

	int i;
	int k;
	int j;



	
	for (i = 0; i < 26; i++){
		for (j = 0; j < 26; j++){
			for (k = 0; k < 26; k++){
				printf("%c%c%c ", a, b, c);
				c++;
			}
			c = 'A';
			b++;
		}
		b = 'A';
		a++;
	}

}