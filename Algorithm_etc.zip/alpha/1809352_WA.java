
public class Main{

	public static void main(String[] args) {
		char a = 'A';
		char b = 'A';
		char c = 'A';
		
		while(a <= 'Z')
		{
			System.out.print("");
			b='A';
			while(b<='Z')
			{
				c='A';
				while(c<='Z')
				{
					
					System.out.print(a+""+b+""+c++ );
					//c++;
				}
				b++;
			}
			a++;
		}

		
	}
}
