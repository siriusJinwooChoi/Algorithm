#include <stdio.h>

int main()
{
    //65~90
    int a,b,c;


    for(a=65;a<=90;a++)
    {
        for(b=65;b<=90;b++)
        {
            for(c=65;c<=90;c++)
            {
                printf("%c%c%c\t",a,b,c);
            }
                
        }
        
    
    }
    return 0;
}