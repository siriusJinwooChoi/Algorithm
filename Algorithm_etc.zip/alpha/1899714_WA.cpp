#include <iostream>

using namespace std;


void ps(char* arr,int N, int currentCount){
    
    char* temp = new char[N];
    for(int i = 0; i<N; ++i){
        temp[i] = arr[i];
    }
    
    if(currentCount == N){
        for(int i = 0; i<N; ++i)   {
            cout<<temp[i];
        } cout<<endl;
        return;
    }
    for(int i = currentCount; i<N; ++i){
        for(int j = 0; j<26; ++j){
            temp[i] = 'A' + j;
            ps(temp,N,currentCount+1);
        }
    }
    
}
int main(){

    
    int N = 3;
    
    char* arr = new char[N];
    for(int i =0; i<N; ++i){
        arr[i] = 'A';
    }
    ps(arr,N,0);
    
    return 0;
}



















