//
//  main.cpp
//  stl_test
//
//  Created by ������ on 2015. 11. 22..
//  Copyright &#169; 2015�� ������. All rights reserved.
//

#include <iostream>
#include <stdio.h>

using namespace std;

void rv(int length,int number,int tonumber,int result[]){
    
    if(tonumber == number){
        for(int i = 0; i<number; ++i)
            printf("%c",result[i] + 'A');
        printf(" ");
        return;
    }
    for(int i = tonumber;i<number;++i){
        for(int j=0; j<length; ++j){
            result[i] =j;
            rv(length,number,i+1,result);
        }
    }
    
}
int main() {
    
    int array[10];
   // scanf("%d%d",&length,&number);
    
    rv(26,3,0,array);
    
    
    
    return 0;
}
