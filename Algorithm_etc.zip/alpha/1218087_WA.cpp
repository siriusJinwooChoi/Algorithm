#include<iostream>

int main(void)
{
	for(int i = 65;  i< 91 ; i++)
	{
		for(int j = 65;  j< 91;  j++)
		{	
			for(int k = 65;  k< 91 ; k++)
			{
				printf("%c", i);
				printf("%c", j);
				printf("%c", k);
			}
		}
		printf(" ");
	}
	
}