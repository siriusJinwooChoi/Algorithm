#include <iostream>
#include <string.h>

using namespace std;

char ch[100] = "ABCDEFGHIJKLMNOPQRSTUVWXYZ";

int main()
{
	int ch_size = strlen(ch);

	for (int i = 0; i < ch_size; i++)
	for (int j = 0; j < ch_size; j++)
	for (int k = 0; k < ch_size; k++)
		cout << ch[i] << ch[j] << ch[k] << " ";
	cout << endl;
	return 0;
}