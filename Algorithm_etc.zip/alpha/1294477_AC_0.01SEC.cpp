#include <iostream>
using namespace std;
int main(){
	char a[3] = {'A','A','A'};
	for(int i=0; i<26;i++){
		for(int j=0; j<26; j++){
			for(int k=0; k<26; k++){
				cout << a[0] << a[1] << a[2] << " ";
				a[2] += 1;
			}
			a[1] += 1;
			a[2] = 'A';
		}
		a[0] += 1;
		a[1] = 'A';
	}
	cout << endl;
}