#include<iostream>

using namespace std;

int main(){
	int i;
	char a='A', b='A', c='A';
	int p=65, q=65, r=65;
	while(p!=91){
		if(r>90){
			r=65;
			q++;
		}
		if(q>90){
			q=65;
			p++;
		}

		cout<<(char)p<<(char)q<<(char)r<<endl;
		if(p=='Z'&&q=='Z'&&r=='Z'){
			return 0;
		}
		r++;
	}
	
}