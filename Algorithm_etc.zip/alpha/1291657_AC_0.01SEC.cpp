#include <iostream>
#include <string>
using namespace std;

int i,j,k;

int main()
{
	char arr[3] = {'A','A','A'};

	for(i=0; i<26; i++)
	{
		for(j=0; j<26; j++)
		{
			for(k=0; k<26; k++)
			{
				cout << arr[0] << arr[1] << arr[2] << " ";
				arr[2] = arr[2] + 1;
			}
			arr[1] = arr[1] + 1;
			arr[2] = 'A';
		}
		arr[0] = arr[0] + 1;
		arr[1] = 'A';

	}
}