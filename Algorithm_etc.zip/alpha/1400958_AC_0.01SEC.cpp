#include <iostream>

using namespace std;

char one = 'A';
char two = 'A';
char three = 'A';

int main()
{
	for( int i = 0; i <= 25; i++ )
	{
		for( int j = 0; j <= 25; j++ )
		{
			for( int k = 0; k <= 25; k++ )
			{
				cout<< (char)(one+i) << (char)(two+j) << (char)(three+k) <<" ";
			}
		}
	}
}