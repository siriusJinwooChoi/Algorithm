#include <iostream>

using namespace std;

int main(){

	char a, b, c;
	a = 'A';
	b = 'A';
	c = 'A';

	while( a <= 'Z' ){
		b = 'A';
		while( b <= 'Z' ){
			c = 'A';
			while( c <= 'Z' ){
				cout << a << b << c++ <<" ";
			}
			b++;
		}
		a++;
	}
}