#include <iostream>
using namespace std;

char arr[30];

int main(){
	char a = 'A';
	int temp = a;

	for (int i = temp; i <= temp + 25; i++){
		char temp_char = i;
		arr[i - 64] = temp_char;
	}

	for (int i = 1; i <= 26; i++){
		for (int j = 1; j <= 26; j++){
			for (int k = 1; k <= 26; k++){
				cout << arr[i] << arr[j] << arr[k] << " ";
			}
		}
	}
	cout << endl;

	return 0;
}