#include<iostream>

using namespace std;

int main() {
	for (int i = 65; i <= 90; i++) {
		printf("%c%c%c ", i,i,i);
	}
	return 0;
}