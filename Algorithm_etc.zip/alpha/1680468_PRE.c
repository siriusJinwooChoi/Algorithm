#include <stdio.h>

char alphaa[26];

int main()
{
	int i,t;
	int a,b,c;

	t = 65;
	for(i=0; i<26; i++){
		alphaa[i] = t;
		t++;
	}
	
	for(a=0; a<26; a++){
		for(b=0; b<26; b++){
			for(c=0; c<26; c++){
				printf("%c%c%c\n",alphaa[a],alphaa[b],alphaa[c]);
			}
		}
	}
	
	return 0;
}