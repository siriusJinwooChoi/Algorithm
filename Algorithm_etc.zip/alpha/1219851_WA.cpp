/*
 * alpha.cpp
 *
 *  Created on: 2014. 3. 20.
 *      Author: mountainHufs
 */
#include <iostream>

using namespace std;

int main(){

	char a, b, c;
	a = 'A';
	b = 'A';
	c = 'A';

	while( a != 'Z' ){

		while( b != 'Z' ){

			while( c != 'Z' ){
				cout << a << b << c << " ";
				c++;
			}
			cout << a << b << c << " ";
			b++;
		}
		cout << a << b << c << " ";
		a++;
	}
	cout << a << b << c;
}
