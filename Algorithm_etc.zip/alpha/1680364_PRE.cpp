#include <iostream>

int main(int argc, const char * argv[])
{
    //65~90


    for(int i=65;i<=90;i++)
    {
        for(int j=65;j<=90;j++)
        {
            for(int t=65;t<=90;t++)
            {
                printf("%c%c%c\n",i,j,t);
            }
                
        }
        
    
    }
    return 0;
}
