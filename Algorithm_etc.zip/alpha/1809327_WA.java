
public class Main{

	public static void main(String[] args) {
		char a = 'A';
		char b = 'A';
		char c = 'A';
		
		while(a <= 'Z')
		{
			b='A';
			while(b<='Z')
			{
				c='A';
				while(c<='Z')
				{
					System.out.print(a+""+b+""+c++);
				}
				b++;
			}
			a++;
		}

		
	}
}
