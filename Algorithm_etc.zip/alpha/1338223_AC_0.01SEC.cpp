#include <stdio.h>
#include "stdlib.h"


int main()
{
	int i,c,k;
	int al = 90;
	
	for(i=65;i<91;i++)
	{
		for(c=65;c<91;c++)
		{
			for(k=65;k<91;k++)
			{
				printf("%c%c%c ",i,c,k);
			}
		}
	}
	
	
	
	return 0;
}