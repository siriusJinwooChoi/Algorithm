#include <iostream>

using namespace std;

int count1 = 0;

void ps(char* arr,int N, int currentCount){
    
    char* temp = new char[N];
    for(int i = 0; i<N; ++i){
        temp[i] = arr[i];
    }
    
    if(currentCount == N){
        count1++;
        for(int i = 0; i<N; ++i)   {
            cout<<temp[i];
        } cout<<" ";
        return;
    }
        for(int j = 0; j<26; ++j){
            temp[currentCount] = 'A' + j;
            ps(temp,N,currentCount+1);
        }
    
}
int main(){
    
    int N = 3;
    
    char* arr = new char[N];
    ps(arr,N,0);
    return 0;
}




















