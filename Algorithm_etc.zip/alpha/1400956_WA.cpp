#include <iostream>

using namespace std;

char one = 'A';
char two = 'A';
char three = 'A';

int main()
{
	for( int i = 0; i <= 1; i++ )
	{
		for( int j = 0; j <= 1; j++ )
		{
			for( int k = 0; k <= 1; k++ )
			{
				cout<< (char)(one+i) << (char)(two+j) << (char)(three+k) <<" ";
			}
		}
	}
}