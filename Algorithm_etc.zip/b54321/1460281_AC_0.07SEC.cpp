#include <iostream>

using namespace std;

int main()
{
	int n;

	cin >> n;

	for(int i=n;i>0;i--){
		for(int j=n-i;j>0;j--){
			cout << " ";
		}
		cout << i;
		for(int k=i-1;k>0;k--){
			cout << k;
		}
		cout << endl;
	}
}