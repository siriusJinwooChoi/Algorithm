#include <stdio.h>

int ans [10002][10002] = {};
int capacity = 0;
int n = 0;
int profit[102] = {}; //���� ������ŭ
int weight[102] = {}; //���� ������ŭ

int max(int val1, int val2) {
	return val1 >= val2 ? val1 : val2;
}

int knapsack() {
	int i = 0;
	int j = 0;
	for (i = 1; i <= n; i++) {
		for (j = 1; j <= capacity; j++) {
			//printf("j : %d weight[i] %d\n", j, weight[i]);
			if (j >= weight[i]) {
				ans[i][j] = max(ans[i - 1][j], profit[i] + ans[i - 1][j - weight[i]]);
				//printf("%d", ans[i][j]);
			} else {
				ans[i][j] = ans[i - 1][j];
			}
		}
	}
}


int main(void) {
	//Scanner sc = new Scanner(System.in);
	//capacity = sc.nextInt();
	scanf("%d",&capacity);
	scanf("%d",&n);
	int i = 0;
	for (i = 1; i <= n; i++) {
		scanf("%d %d", &weight[i], &profit[i]);
	}
	// for (i = 1; i <= n; i++) {
		// printf("%d : weight: %d profit: %d\n",i, weight[i], profit[i]);
	// }
	knapsack();

	printf("%d\n", ans[n][capacity]);

}