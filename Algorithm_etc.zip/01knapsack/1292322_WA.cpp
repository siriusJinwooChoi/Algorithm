#include <iostream>
using namespace std;

struct Jewel {
	int w;
	int v;
};

Jewel J[101];
int JN;
int Bag_Size;
int result[101][10001];
bool select[101];

void swap(Jewel& A, Jewel& B) {
	Jewel temp = A;
	A = B;
	B = temp;
}

void bubblesort() {
	for(int i=1;i<=JN;i++) {
		for(int j=1;j<JN;j++) {
			if(J[j].v < J[j+1].v)
				swap(J[j],J[j+1]);
		}
	}
}

void init() {
	for(int i=0;i<101;i++) {
		select[i] = false;
		for(int j=0;j<10001;j++) {
			result[i][j] = 0;
		}
	}
}

void initSelect() {
	for(int i=0;i<101;i++) {
		select[i] = false;
	}
}

void process() {
	for(int i=1;i<=JN;i++) {
		int S = 0;
		for(int j=1;j<=Bag_Size;j++) {
			int max = 0;
			int empty = j;
			for(int k=1;k<=i;k++) {
				if(empty >= J[k].w) {
					max = max + J[k].v;
					empty = empty - J[k].w;
				}
			}
			if(max > result[i-1][j]) {
				result[i][j] = max;
			}
			else {
				result[i][j] = result[i-1][j];
			}
		}
	}
}

int main() {
	cin >> Bag_Size;
	cin >> JN;
	for(int i=1;i<=JN;i++) {
		cin >> J[i].w;
		cin >> J[i].v;
	}
	bubblesort();
	process();
	/*for(int i=1;i<=JN;i++) {
		for(int j=1;j<=Bag_Size;j++) {
			cout << result[i][j] << " ";
		}
		cout <<endl;
	}*/
	cout << result[JN][Bag_Size] <<endl;
} 
