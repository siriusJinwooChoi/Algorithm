#include <iostream>
using namespace std;

int dp[100+1][10000+1];

int max(int a,int b){
	return a>b ? a : b;	
}
int main() {
	int weight[101];
	int value[101];
	int n;
	int limit;
	cin>>limit;
	cin>>n;
	for(int i=1;i<=n;i++){
		cin>>weight[i];
		cin>>value[i];
	}
	for(int i=1;i<=n;i++){
		for(int j=0;j<=limit;j++){
			if(j-weight[i]>=0){
				dp[i][j] = max(dp[i-1][j],dp[i-1][j-weight[i]]+value[i]);
			}
		}
	}
	cout<<dp[n][limit]<<endl;
	return 0;
}