import java.util.Scanner;

public class Main {
	
	static int [][] ans = new int [10002][10002];
	static int capacity = 0;
	static int n = 0;
	static int [] profit = new int[102]; //���� ������ŭ
	static int [] weight = new int[102]; //���� ������ŭ

	static int knapsack () {
		for (int i = 1; i <= n; i++) {
			for (int j = 1; j <= capacity; j++) {
				if(j >= weight[i]) {
					ans[i][j] = max(ans[i - 1][j], profit[i] + ans[i - 1][j - weight[i]]);
				} else {
					ans[i][j] = ans[i - 1][j];
				}
			}
		}
		
		return ans[n][capacity];
	}
	static int max(int val1, int val2) {
		return val1 >= val2 ? val1 : val2;
	}
	
	public static void main(String[] args) {
		Scanner sc = new Scanner(System.in);
		capacity = sc.nextInt();
		sc.nextLine();
		n = sc.nextInt();
		sc.nextLine();
		
		for(int i = 1; i <= n; i++) {
			String[] tmp = sc.nextLine().split(" ");
			weight[i] = Integer.parseInt(tmp[0]);
			profit[i] = Integer.parseInt(tmp[1]);
		}
		
//		System.out.printf("capacity : %d  ���� : %d ",capacity, n);
//		
//		for (int i = 0; i <= n; i++) {
//			System.out.println("���� "+profit[i]+" ��"+weight[i]);
//		}
		
		System.out.println(knapsack());
	}

}