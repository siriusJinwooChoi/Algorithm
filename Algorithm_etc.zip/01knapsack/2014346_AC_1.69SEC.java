import java.util.Scanner;

public class Main {
	public static void main(String args[]) {
		Scanner sc = new Scanner(System.in);
		int limit = sc.nextInt();
		int N = sc.nextInt();
		int jewels[][] = new int[N+1][2];
		for(int i=1; i<=N ; i++) {
			jewels[i][0] = sc.nextInt(); // weight
			jewels[i][1] = sc.nextInt(); // value
		}

		int dp[][] = new int[N+1][limit+1];
		//i��° ����, ���� ũ�� j�� ���� �� �ִ� �ִ� ��
		for(int i=1 ; i<= N ; i++) {
            for(int j=0 ; j<=limit ; j++) {
                int restWeight = j - jewels[i][0];
                if(restWeight >= 0) {
                    dp[i][j] = Math.max(dp[i-1][j], dp[i-1][restWeight]+jewels[i][1]);
                } else {
                    dp[i][j] = dp[i-1][j];
                }
            }
        }
		System.out.println(dp[N][limit]);
	}
}