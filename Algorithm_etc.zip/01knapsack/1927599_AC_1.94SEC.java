import java.util.Scanner;

public class Main {
	
	public static void main(String arg[]){
        Scanner input = new Scanner(System.in);
        int dp[][] = new int[100+1][10000+1];
        int weight[] = new int[100+1];
        int value[] = new int[100+1];
        int n, limit;
        
        limit = input.nextInt();
        n = input.nextInt();
        for(int i=1 ; i<=n ; i++) {
        	weight[i] = input.nextInt();
        	value[i] = input.nextInt();
        }
        
        for(int i=1 ; i<= n ; i++) {
        	for(int j=0 ; j<=limit ; j++) {
        		int restWeight = j - weight[i];
        		if(restWeight >= 0) {
        			dp[i][j] = Math.max(dp[i-1][j], dp[i-1][restWeight]+value[i]);
        		} else {
        			dp[i][j] = dp[i-1][j];
        		}
        	}
        }
        
        System.out.println(dp[n][limit]);
    }
}