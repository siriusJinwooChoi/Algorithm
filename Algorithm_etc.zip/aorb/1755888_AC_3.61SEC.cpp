
#include<iostream>
using namespace std;

int n,cnt;

int main() {
	cin >> n;
	for (int i = 1; i <= n; i++)
		if (i % 6 == 0 || i % 8 == 0)
			cnt++;
	cout << cnt;
	return 0;
}