#include <iostream>
using namespace std;

int main() {
int n, count=0;
cin >> n;
for(int i = 0; i<=n; i++)
if(i%6 == 0 || i%8 == 0) count++;
cout << count-1;
}