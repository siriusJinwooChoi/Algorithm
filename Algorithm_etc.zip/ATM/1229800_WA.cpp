#include <iostream>
using namespace std;

int main() {
	int X;
	double Y;
	cin >> X >> Y;

	cout.precision(2);
	cout.setf(ios_base::fixed);
	cout.setf(ios_base::showpoint);

	if((X%5 !=0) || (X > Y))
		cout << Y <<endl;
	else {
		cout << Y-(X + 0.5) <<endl;
	}
}