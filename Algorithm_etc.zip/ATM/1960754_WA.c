#include<stdio.h>

int main() {

	int output;
	float firstSum;

	scanf("%d %f", &output, &firstSum);

	if (output > firstSum)
	{
		printf("%.2f", firstSum);
	}
	else if (output % 5 != 0)
	{
		printf("%.2f", firstSum);
	}
	else
	{
		printf("%.2f\n", firstSum - (float)output);
	}

}