#include <iostream>

using namespace std;

int main()
{
	double a, b;

	cin >> a >> b;

	if((int)a % 5 != 0)
	{
		printf("%.2f\n", b);
		return 0;
	}

	if(a > b)
	{
		printf("%.2f\n", b);
		return 0;
	}

	printf("%.2f\n", b-a-0.5);
}