#include<stdio.h>

int main() {

	int output;
	float firstSum;
	float result;

	scanf("%d %f", &output, &firstSum);

	if (output > firstSum)
	{
		printf("%.2f", firstSum);
	}
	else if (output % 5 != 0)
	{
		printf("%.2f", firstSum);
	}
	else
	{
		result = firstSum - (float)output;
		if(result!=0)
		{
			printf("%.2f\n", result-0.5);
		}
		else
		{
			printf("%.2f\n", result);
		}
	}

}