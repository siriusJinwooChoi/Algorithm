#include <stdio.h>
int main(){
	int input1;
	double input2,result;

	scanf("%d %lf", &input1, &input2);

	result = input2-input1-0.5;
	if(result <0 || input1%5!=0) result = input2;
	
	printf("%.2f" ,result);
	return 0;
}
