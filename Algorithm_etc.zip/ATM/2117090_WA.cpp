#pragma warning(disable:4996)
#include<stdio.h>
#include<iostream>
using namespace std;

int main(){
	int out;
	float account_money;
	float result = 0;

	scanf("%d %f", &out, &account_money);

	if (out % 5 != 0){ cout << account_money << endl; return 0; }
	else {
		result = account_money - out;
		if (result < 0.5){ cout << account_money << endl; return 0; }
		printf("%.2f\n", result - 0.5);
		return 0;
	}
	
}