#include <iostream>

using namespace std;

int main(){
	int a;
	float b;

	cin >> a >> b;

	if (b > (float) a){
		if (a % 5 == 0){
			b = b - a - 0.5;
		}
	}

	cout << b << endl;
}