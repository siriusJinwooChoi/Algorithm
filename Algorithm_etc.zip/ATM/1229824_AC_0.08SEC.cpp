#include <iostream>
using namespace std;

int main() {
	double X;
	double Y;
	cin >> X >> Y;
	int X_int = X;

	cout.precision(2);
	cout.setf(ios_base::fixed);
	cout.setf(ios_base::showpoint);

	if((X_int%5 !=0) || (Y < (X + 0.5)))
		cout << Y <<endl;
	else {
		cout << Y-(X + 0.5) <<endl;
	}
}