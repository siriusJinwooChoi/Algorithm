#include <iostream>
int main(){
	int a;
	double b;
	std::cin >> a >> b;
	if ((a % 5 == 0) && a < b-0.5)
		printf("%.2f", b - a - 0.5);
	else
		printf("%.2f", b);
}