#include <stdio.h>

int main(void)
{
	int X;
	double Y, change=0;

	scanf("%d %lf", &X, &Y);

	if((X%5==0)&&(Y>=X))
	{
		change = Y-X-0.5;
	}
	else
		change = Y;

	printf("%.2lf", change);

	return 0;
}
