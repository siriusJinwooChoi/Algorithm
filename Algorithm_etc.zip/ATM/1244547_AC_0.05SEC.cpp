#include <iostream>

using namespace std;

int main(){

	int outputMoney;
	double account;

	cin >> outputMoney >> account;

	cout << fixed;
	cout.precision(2);
	if( outputMoney % 5 != 0 || account - outputMoney < 0.5 ){
		cout << account << endl;
		return 0;
	}
	else{
		cout << account - outputMoney - 0.5 << endl;
	}
}